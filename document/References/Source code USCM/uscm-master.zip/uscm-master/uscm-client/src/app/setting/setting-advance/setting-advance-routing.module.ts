import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SettingAdvanceComponent } from './setting-advance.component';
import { Role } from 'src/app/models/Role';

const routes: Routes = [{ path: '', component: SettingAdvanceComponent, data: { roles: [Role.Root] } }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingAdvanceRoutingModule { }
