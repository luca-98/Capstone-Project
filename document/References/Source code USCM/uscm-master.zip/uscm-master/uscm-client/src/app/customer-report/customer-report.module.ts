import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerReportRoutingModule } from './customer-report-routing.module';
import { CustomerReportComponent } from './customer-report.component';


@NgModule({
  declarations: [
    CustomerReportComponent
  ],
  imports: [
    CommonModule,
    CustomerReportRoutingModule
  ]
})
export class CustomerReportModule { }
