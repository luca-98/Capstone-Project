import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptor } from './core/interceptor/loader.interceptor';
import { JwtInterceptor } from './core/interceptor/jwt.interceptor';
import { ErrorInterceptor } from './core/interceptor/error.interceptor';
import { ShellModule } from './shell/shell.module';
import { ErrorModule } from './error/error.module';
import { ConfirmDialogComponent } from './shared/dialogs/confirm-dialog/confirm-dialog.component';
import { NotifyDialogComponent } from './shared/dialogs/notify-dialog/notify-dialog.component';
import { ConfirmDeleteDialogComponent } from './shared/dialogs/confirm-delete-dialog/confirm-delete-dialog.component';
import { ChangePasswordDialogComponent } from './shared/dialogs/change-password-dialog/change-password-dialog.component';
import { MatPaginatorIntl } from '@angular/material';
import { getVietnamesePaginatorIntl } from './core/vietnamese-paginator.intl';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ErrorModule,
    ShellModule,
    AppRoutingModule
  ],
  entryComponents: [
    NotifyDialogComponent,
    ConfirmDialogComponent,
    ConfirmDeleteDialogComponent,
    ChangePasswordDialogComponent,
  ],
  providers: [
    Title,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: MatPaginatorIntl, useValue: getVietnamesePaginatorIntl() }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
