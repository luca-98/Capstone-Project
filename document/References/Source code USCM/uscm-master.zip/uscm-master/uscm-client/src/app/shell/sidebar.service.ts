import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SidebarService {
  reloadDataSidebarChange: Subject<any> = new Subject();
  sideNavOpenChange: Subject<boolean> = new Subject();

  constructor() { }

  setSideNavOpen(open: boolean) {
    this.sideNavOpenChange.next(open);
  }

  reloadDataSidebar() {
    this.reloadDataSidebarChange.next();
  }
}
