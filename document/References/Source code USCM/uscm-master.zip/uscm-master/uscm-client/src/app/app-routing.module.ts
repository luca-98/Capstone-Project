import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { Shell } from './shell/shell.service';


const routes: Routes = [
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'customer-report', loadChildren: () => import('./customer-report/customer-report.module').then(m => m.CustomerReportModule) },
  Shell.childRoutes([
    { path: '', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
    { path: 'report', loadChildren: () => import('./report/report.module').then(m => m.ReportModule) },
    { path: 'setting', loadChildren: () => import('./setting/setting.module').then(m => m.SettingModule) },
    { path: 'search-customer', loadChildren: () => import('./search-customer/search-customer.module').then(m => m.SearchCustomerModule) },
  ]),

  // Fallback when no prior route is matched
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule { }