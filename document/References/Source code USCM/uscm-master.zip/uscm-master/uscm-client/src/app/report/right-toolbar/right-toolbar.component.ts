import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';
import { LoaderState } from 'src/app/core/loader';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { ForwardService } from 'src/app/editor/forward.service';
import { AdditionalDialogComponent } from '../additional-dialog/additional-dialog.component';

declare var $: any;

@Component({
  selector: 'app-right-toolbar',
  templateUrl: './right-toolbar.component.html',
  styleUrls: ['./right-toolbar.component.scss']
})
export class RightToolbarComponent implements OnInit {
  subscription: Subscription;
  needSave = false;

  constructor(
    private restService: RestService,
    private loaderService: LoaderService,
    private forwardService: ForwardService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.forwardService.saveSubject.subscribe(() => {
      this.needSave = true;
    });
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
  }

  changeNeedSaveFlag(value: boolean) {
    this.needSave = value;
  }

  print() {
    const editor = document.getElementById('editor');
    const listTable: any = editor.getElementsByTagName('table');
    for (const table of listTable) {
      $(table).colResizable({
        disable: true
      });
    }
    $("#editor").printThis({ importCSS: false });
    setTimeout(function () {
      for (const table of listTable) {
        $(table).colResizable({
          liveDrag: true,
          draggingClass: "dragging"
        });
      }
    }, 1500);
  }

  removeSignAndLowerCase(str: string) {
    str = str.trim();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "a");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "e");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "i");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "o");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "u");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "y");
    str = str.replace(/Đ/g, "d");
    str = str.toLowerCase();
    return str;
  }

  standardizeSpaceString(str: string) {
    str = str.trim();
    return str.replace(/\s+/g, ' ');
  }

  standardizeString(str: string) {
    str = this.standardizeSpaceString(str);
    str = str.toLowerCase();
    const temp = str.split(" ");
    str = "";
    for (let i = 0; i < temp.length; i++) {
      str += temp[i].charAt(0).toUpperCase() + temp[i].substring(1);
      if (i < temp.length - 1) {
        str += " ";
      }
    }
    return str;
  }

  // convert dateTime object to dd/MM/yyyy
  convertDateToNormal(d: any): string {
    if (!d) {
      return d;
    }
    const date = d._d.getDate();
    const month = d._d.getMonth() + 1;
    const year = d._d.getFullYear();
    return date + "/" + month + "/" + year;
  }

  save() {
    // validate input
    if ($('#input-name').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập tên" },
      });
      return;
    }

    if ($('#input-age').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập tuổi" },
      });
      return;
    }

    if ($('#input-address').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập địa chỉ" },
      });
      return;
    }

    if ($('#input-result').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập kết quả" },
      });
      return;
    }

    // get name and validate
    const name = this.standardizeString($('#input-name').val());
    if (name === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập tên" },
      });
      return;
    }

    // get name search
    const nameSearch = this.removeSignAndLowerCase(name);

    // get age and validate
    const ageStr = $('#input-age').val().trim();
    let age = "";
    for (let i = 0; i < ageStr.length; i++) {
      const c = ageStr.substring(i, i + 1);
      if ('0123456789'.indexOf(c) !== -1) {
        age += ageStr.substring(i, i + 1);
      }
    }
    if (age === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập tuổi" },
      });
      return;
    }
    if (Number(age) <= 0 || Number(age) > 150) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Tuổi bạn nhập không hợp lệ" },
      });
      return;
    }

    // get year of birth
    const currentYear = new Date().getFullYear();
    const yearOfBirth = currentYear - Number(age);

    // get address and validate
    const address = this.standardizeString($('#input-address').val());
    if (address === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập địa chỉ" },
      });
      return;
    }

    //get address search
    const addressSearch = this.removeSignAndLowerCase(address);

    // get result and validate
    const result = $('#input-result').val().trim();
    if (result === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập kết quả" },
      });
      return;
    }

    const dialogRef = this.dialog.open(AdditionalDialogComponent, {
      width: '400px',
      disableClose: true,
      autoFocus: false,
      position: { top: '60px' }
    });

    dialogRef.afterClosed().subscribe(res => {
      if (res) {
        const editor = document.getElementById('editor');
        const listTable: any = editor.getElementsByTagName('table');
        for (const table of listTable) {
          $(table).colResizable({
            disable: true
          });
        }
        this.freezeInput();
        const listTd: any = editor.getElementsByTagName("td");
        for (const tdTag of listTd) {
          if (tdTag.innerHTML === "") {
            tdTag.innerHTML = "\u00A0";
          }
        }
        const report = editor.innerHTML;

        const phonenumber = res.get('phonenumber').value;
        const expectedDateOfBirth = this.convertDateToNormal(res.get('expectedDateOfBirth').value);
        const note = res.get('note').value;
        this.restService.addCustomer(name, nameSearch, address, addressSearch, String(yearOfBirth),
          result, report, phonenumber, expectedDateOfBirth, note)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Lưu kết quả thành công" },
              });
              for (const table of listTable) {
                $(table).colResizable({
                  liveDrag: true,
                  draggingClass: "dragging"
                });
              }
              this.unFreezeInput();
              this.needSave = false;
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
              for (const table of listTable) {
                $(table).colResizable({
                  liveDrag: true,
                  draggingClass: "dragging"
                });
              }
              this.unFreezeInput();
            }
          );
      }
    });
  }

  freezeInput() {
    $('#input-name').attr("value", $('#input-name').val());
    $('#input-name').prop('readonly', true);
    $('#input-name').css("outline", "none");
    $('#input-age').attr("value", $('#input-age').val());
    $('#input-age').prop('readonly', true);
    $('#input-age').css("outline", "none");
    $('#input-address').attr("value", $('#input-address').val());
    $('#input-address').prop('readonly', true);
    $('#input-address').css("outline", "none");
    $('#input-result').html($('#input-result').val());
    $('#input-result').prop('readonly', true);
    $('#input-result').css("outline", "none");

    $('.auto-date').attr("class", "auto-date-freeze");
  }

  unFreezeInput() {
    $('#input-name').removeAttr("value");
    $('#input-name').removeAttr('readonly');
    $('#input-name').css("outline", "");
    $('#input-age').removeAttr("value");
    $('#input-age').removeAttr('readonly');
    $('#input-age').css("outline", "");
    $('#input-address').removeAttr("value");
    $('#input-address').removeAttr('readonly');
    $('#input-address').css("outline", "");
    $('#input-result').removeAttr('readonly');
    $('#input-result').css("outline", "");

    $('.auto-date-freeze').attr("class", "auto-date");
  }
}
