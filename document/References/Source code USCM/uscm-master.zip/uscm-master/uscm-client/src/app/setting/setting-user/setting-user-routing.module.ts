import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SettingUserComponent } from './setting-user.component';
import { Role } from 'src/app/models/Role';

const routes: Routes = [
  { path: '', component: SettingUserComponent, data: { roles: [Role.Admin, Role.Root] } }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingUserRoutingModule { }
