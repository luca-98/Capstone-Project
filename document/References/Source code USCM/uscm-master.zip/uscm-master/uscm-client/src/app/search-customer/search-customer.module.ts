import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchCustomerRoutingModule } from './search-customer-routing.module';
import { SearchCustomerComponent } from './search-customer.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MAT_DATE_LOCALE } from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { MatButtonModule } from '@angular/material/button';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ShowReportDialogComponent } from './show-report-dialog/show-report-dialog.component';
import { MatTooltipModule } from '@angular/material/tooltip';


@NgModule({
  declarations: [SearchCustomerComponent, ShowReportDialogComponent],
  imports: [
    CommonModule,
    SearchCustomerRoutingModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    FormsModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatPaginatorModule,
    MatTooltipModule
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'vi-VN' },
    MatDatepickerModule,
  ],
  entryComponents: [
    ShowReportDialogComponent
  ]
})
export class SearchCustomerModule { }
