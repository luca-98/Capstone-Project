import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ReportForm } from 'src/app/models/ReportFormModel';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { LoaderState } from 'src/app/core/loader';
import { SidebarService } from 'src/app/shell/sidebar.service';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { ConfirmDeleteDialogComponent } from 'src/app/shared/dialogs/confirm-delete-dialog/confirm-delete-dialog.component';
import { Title } from '@angular/platform-browser';
import { AddEditGroupDialogComponent } from './add-edit-group-dialog/add-edit-group-dialog.component';
import { Router } from '@angular/router';

interface ReportFormSetting extends ReportForm {
  isShow: boolean;
  groupCollapse: boolean;
  disableSortUp: boolean;
  disableSortDown: boolean;
}

@Component({
  selector: 'app-setting-report',
  templateUrl: './setting-report.component.html',
  styleUrls: ['./setting-report.component.scss']
})
export class SettingReportComponent implements OnInit {
  subscription: Subscription;
  reportForms: ReportFormSetting[] = new Array();
  lastEditArray: string[] = new Array();
  checkboxArr: boolean[] = new Array();
  checkAll: boolean = false;
  disabledDelete = true;
  disabledEdit = true;
  currentIdChecked: string[] = new Array();

  constructor(
    private restService: RestService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
    private sidebarService: SidebarService,
    private titleService: Title,
    private router: Router,
  ) { }

  ngOnInit() {
    this.titleService.setTitle("Quản lý mẫu kết quả");
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.getAllReport();
  }

  onCheckAll(event: any) {
    for (let i = 0; i < this.checkboxArr.length; i++) {
      this.checkboxArr[i] = event.checked;
    }
    if (event.checked) {
      for (const report of this.reportForms) {
        this.currentIdChecked.push(report.id);
      }
    } else {
      this.currentIdChecked = new Array();
    }
    this.updateStatus();
  }

  checkReport(event: any, reportId: string) {
    if (event.checked) {
      this.currentIdChecked.push(reportId);
    } else {
      for (let i = 0; i < this.currentIdChecked.length; i++) {
        if (this.currentIdChecked[i] === reportId) {
          this.currentIdChecked.splice(i, 1);
        }
      }
    }
    this.updateStatus();
  }

  updateStatus() {
    let countChecked = 0;
    for (let i = 0; i < this.checkboxArr.length; i++) {
      if (this.checkboxArr[i]) {
        countChecked++;
      }
    }
    if (countChecked === 1) {
      this.disabledEdit = false;
    } else {
      this.disabledEdit = true;
    }
    if (countChecked > 0) {
      this.disabledDelete = false;
    } else {
      this.disabledDelete = true;
    }
    if (countChecked === this.checkboxArr.length && this.checkboxArr.length !== 0) {
      this.checkAll = true;
    } else {
      this.checkAll = false;
    }
  }

  getAllReport() {
    this.restService.getAllReport()
      .subscribe(
        (data: any) => {
          // sort by orderNumber
          data.sort((a: any, b: any) =>
            (a.orderNumber > b.orderNumber) ? 1 : ((b.orderNumber > a.orderNumber) ? -1 : 0)
          );
          this.currentIdChecked = new Array();
          this.checkboxArr = new Array();
          this.reportForms = new Array();
          for (let i = 0; i < data.length; i++) {
            this.checkboxArr[i] = false;
            const date = new Date(data[i].lastEdit);
            this.lastEditArray[i] = date.toLocaleString("en-GB");
            const reportFormSetting: ReportFormSetting = data[i];
            reportFormSetting.isShow = true;
            if (reportFormSetting.groupFlag) {
              reportFormSetting.groupCollapse = false;
            }
            reportFormSetting.disableSortDown = false;
            reportFormSetting.disableSortUp = false;
            this.reportForms.push(reportFormSetting);
          }
          this.checkDisableSort();
          this.updateStatus();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  checkDisableSort() {
    // disable sort up first element
    this.reportForms[0].disableSortUp = true;

    // disable sort down last element
    this.reportForms[this.reportForms.length - 1].disableSortDown = true;

    // disable sort first and last child element of any group
    for (let i = 0; i < this.reportForms.length; i++) {
      if (this.reportForms[i].groupFlag) {
        let haveChild = false;
        let isFirst = true;
        for (let j = i + 1; j < this.reportForms.length; j++) {
          // disable sort up first child
          if (this.reportForms[j].parentGroup !== null &&
            this.reportForms[j].parentGroup.id === this.reportForms[i].id && isFirst) {
            this.reportForms[j].disableSortUp = true;
            haveChild = true;
            isFirst = false;
          }
          // disable sort down first child
          if (this.reportForms[j].parentGroup === null && haveChild) {
            this.reportForms[j - 1].disableSortDown = true;
            break;
          }
        }
      }
    }

    // disable sort down last group when dont have report last
    for (let i = this.reportForms.length - 1; i >= 0; i--) {
      if (!this.reportForms[i].groupFlag && this.reportForms[i].parentGroup === null) {
        break;
      }
      if (this.reportForms[i].groupFlag) {
        this.reportForms[i].disableSortDown = true;
        break;
      }
    }
  }

  groupCollapseClick(id: string, statusCollapse: boolean) {
    statusCollapse = !statusCollapse;
    for (const r of this.reportForms) {
      if (r.id === id) {
        r.groupCollapse = statusCollapse;
      }
      if (r.parentGroup !== null && r.parentGroup.id === id) {
        r.isShow = !statusCollapse;
      }
    }
  }

  deleteReport() {
    const dialogRef = this.dialog.open(ConfirmDeleteDialogComponent, {
      width: '350px',
      disableClose: true,
      autoFocus: false,
      data: {
        title: "Thông báo",
        content: "Bạn có muốn xóa các mẫu kết quả này không?"
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const listReport: ReportForm[] = new Array();
        for (const id of this.currentIdChecked) {
          for (const report of this.reportForms) {
            if (report.parentGroup !== null && report.parentGroup.id === id) {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Bạn đã chọn nhóm kết quả mà có kết quả ở trong, không thể thực hiện xóa, vui lòng xóa các kết quả bên trong nhóm kết quả và thử lại" },
              });
              return;
            }
          }
          listReport.push({
            id: id
          })
        }
        this.restService.deleteReports(listReport)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Xóa thành công" },
              });
              this.getAllReport();
              this.sidebarService.reloadDataSidebar();
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
            }
          )
      }
    });
  }

  upSort(reportId: string) {
    for (let i = 0; i < this.reportForms.length; i++) {
      if (reportId === this.reportForms[i].id) {
        const tempOrder = this.reportForms[i].orderNumber;
        if (this.reportForms[i].groupFlag) {
          const totalChild = this.countChildReport(this.reportForms[i].id);
          if (this.reportForms[i - 1].parentGroup === null) {
            this.reportForms[i - 1].orderNumber = this.reportForms[i - 1].orderNumber + 1 + totalChild;
            this.reportForms[i].orderNumber = this.reportForms[i].orderNumber - 1;
            for (let j = 1; j <= totalChild; j++) {
              this.reportForms[i + j].orderNumber = this.reportForms[i + j].orderNumber - 1;
            }
          } else {
            for (let j = i - 2; j >= 0; j--) {
              if (this.reportForms[j].id === this.reportForms[i - 1].parentGroup.id) {
                const totalChildUp = this.countChildReport(this.reportForms[j].id);
                for (let k = 0; k <= totalChild; k++) {
                  this.reportForms[i + k].orderNumber = this.reportForms[i + k].orderNumber - totalChildUp - 1;
                }
                for (let k = 0; k <= totalChildUp; k++) {
                  this.reportForms[j + k].orderNumber = this.reportForms[j + k].orderNumber + totalChild + 1;
                }
              }
            }
          }
        } else {
          if (this.reportForms[i - 1].parentGroup === null) {
            this.reportForms[i].orderNumber = this.reportForms[i - 1].orderNumber;
            this.reportForms[i - 1].orderNumber = tempOrder;
          } else {
            if (this.reportForms[i].parentGroup !== null) {
              this.reportForms[i].orderNumber = this.reportForms[i - 1].orderNumber;
              this.reportForms[i - 1].orderNumber = tempOrder;
            } else {
              for (let j = i - 1; j >= 0; j--) {
                if (this.reportForms[j].id === this.reportForms[i - 1].parentGroup.id) {
                  this.reportForms[i].orderNumber = this.reportForms[j].orderNumber;
                  this.reportForms[j].orderNumber = this.reportForms[j].orderNumber + 1;
                  break;
                }
                this.reportForms[j].orderNumber = this.reportForms[j].orderNumber + 1;
              }
            }
          }
        }
      }
    }
    this.restService.updateReports(this.reportForms)
      .subscribe(
        () => {
          this.getAllReport();
          this.sidebarService.reloadDataSidebar();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng tải lại trang" },
          });
        }
      )
  }

  downSort(reportId: string) {
    for (let i = 0; i < this.reportForms.length; i++) {
      if (reportId === this.reportForms[i].id) {
        if (this.reportForms[i].groupFlag) {
          const countChild = this.countChildReport(this.reportForms[i].id);
          let temp = this.reportForms[i].orderNumber;
          this.reportForms[i + countChild + 1].orderNumber = temp;
          if (this.reportForms[i + countChild + 1].groupFlag) {
            const countChildDown = this.countChildReport(this.reportForms[i + countChild + 1].id);
            this.reportForms[i].orderNumber = temp + 1 + countChildDown;
            for (let j = i + 1; j < this.reportForms.length; j++) {
              if (this.reportForms[j].parentGroup !== null
                && this.reportForms[j].parentGroup.id === this.reportForms[i].id) {
                this.reportForms[j].orderNumber = j + 1 + countChildDown;
              }
            }
            if (countChildDown !== 0) {
              for (let j = i + countChild + 2; j < this.reportForms.length; j++) {
                if (this.reportForms[j].parentGroup !== null
                  && this.reportForms[j].parentGroup.id === this.reportForms[i + countChild + 1].id) {
                  this.reportForms[j].orderNumber = j - 1 - countChild;
                }
              }
            }
          } else {
            this.reportForms[i].orderNumber = temp + 1;
            if (countChild !== 0) {
              const t = i + countChild + 1;
              for (let j = i + 1; j < this.reportForms.length; j++) {
                if (this.reportForms[j].parentGroup !== null
                  && this.reportForms[j].parentGroup.id === this.reportForms[i].id) {
                  this.reportForms[j].orderNumber = this.reportForms[j].orderNumber + 1;
                }
              }
            }
          }
        } else {
          if (this.reportForms[i + 1].groupFlag) {
            const countChild = this.countChildReport(this.reportForms[i + 1].id);
            let temp = this.reportForms[i].orderNumber;
            this.reportForms[i].orderNumber = i + 1 + countChild;
            this.reportForms[i + 1].orderNumber = temp;
            if (countChild !== 0) {
              for (let j = i + 2; j < this.reportForms.length; j++) {
                if (this.reportForms[j].parentGroup !== null
                  && this.reportForms[j].parentGroup.id === this.reportForms[i + 1].id) {
                  this.reportForms[j].orderNumber = this.reportForms[j].orderNumber - 1;
                }
              }
            }
          } else {
            const orderNumberTemp = this.reportForms[i].orderNumber;
            this.reportForms[i].orderNumber = this.reportForms[i + 1].orderNumber;
            this.reportForms[i + 1].orderNumber = orderNumberTemp;
          }
        }
      }
    }
    this.restService.updateReports(this.reportForms)
      .subscribe(
        () => {
          this.getAllReport();
          this.sidebarService.reloadDataSidebar();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng tải lại trang" },
          });
        }
      )
  }

  countChildReport(reportId: string): number {
    let count = 0;
    for (const report of this.reportForms) {
      if (report.parentGroup !== null && report.parentGroup.id === reportId) {
        count++;
      }
    }
    return count;
  }

  addGroupReport() {
    const dialogRef = this.dialog.open(AddEditGroupDialogComponent, {
      width: '400px',
      disableClose: true,
      autoFocus: false,
      position: { top: '120px' },
      data: { title: "Thêm nhóm kết quả mới", groupOpenDefault: false }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.restService.addReport(result.reportName, null, "true", null, result.groupOpenDefault)
          .subscribe(
            () => {
              const dialogRefNoti = this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Thêm nhóm kết quả thành công" },
              });

              dialogRefNoti.afterClosed().subscribe(() => {
                this.getAllReport();
                this.sidebarService.reloadDataSidebar();
              });
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
            }
          )
      }
    });
  }

  editGroup(id: string) {
    for (const report of this.reportForms) {
      if (report.id === id) {
        if (report.groupFlag) {
          const dialogRef = this.dialog.open(AddEditGroupDialogComponent, {
            width: '400px',
            disableClose: true,
            autoFocus: false,
            position: { top: '120px' },
            data: { title: "Sửa nhóm kết quả", reportName: report.reportName, groupOpenDefault: report.groupOpenDefault }
          });

          dialogRef.afterClosed().subscribe(result => {
            if (result) {
              this.restService.updateReport(id, result.reportName, null, "true", null, result.groupOpenDefault)
                .subscribe(
                  () => {
                    const dialogRefNoti = this.dialog.open(NotifyDialogComponent, {
                      width: '350px',
                      disableClose: true,
                      autoFocus: false,
                      data: { title: "Thông báo", content: "Sửa nhóm kết quả thành công" },
                    });

                    dialogRefNoti.afterClosed().subscribe(() => {
                      this.getAllReport();
                      this.sidebarService.reloadDataSidebar();
                    });
                  },
                  () => {
                    this.dialog.open(NotifyDialogComponent, {
                      width: '350px',
                      disableClose: true,
                      autoFocus: false,
                      data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
                    });
                  }
                )
            }
          });
        } else {
          this.router.navigate(['/setting/report/edit', id]);
        }
        break;
      }
    }
  }
}
