import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingAdvanceRoutingModule } from './setting-advance-routing.module';
import { SettingAdvanceComponent } from './setting-advance.component';
import { MatCardModule, MatButtonModule, MatTooltipModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from 'src/app/shared/toast/toast.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';


@NgModule({
  declarations: [SettingAdvanceComponent],
  imports: [
    CommonModule,
    SharedModule,
    SettingAdvanceRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatTooltipModule,
    MatFormFieldModule,
    FormsModule,
    MatSlideToggleModule
  ],
  entryComponents: [
    ToastComponent
  ]
})
export class SettingAdvanceModule { }
