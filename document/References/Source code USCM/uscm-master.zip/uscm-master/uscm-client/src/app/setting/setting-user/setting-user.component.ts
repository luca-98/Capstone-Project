import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { LoaderState } from 'src/app/core/loader';
import { AppUser } from 'src/app/models/UserModel';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { ConfirmDeleteDialogComponent } from 'src/app/shared/dialogs/confirm-delete-dialog/confirm-delete-dialog.component';
import { AddUserDialogComponent } from './add-user-dialog/add-user-dialog.component';
import { Role } from 'src/app/models/Role';
import { AppRole } from 'src/app/models/RoleModel';
import { EditUserDialogComponent } from './edit-user-dialog/edit-user-dialog.component';
import { CredentialsService } from 'src/app/core/service/credentials.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-setting-user',
  templateUrl: './setting-user.component.html',
  styleUrls: ['./setting-user.component.scss']
})
export class SettingUserComponent implements OnInit {
  subscription: Subscription;
  disabledDelete = true;
  disabledEdit = true;
  checkAll: boolean = false;
  checkboxArr: boolean[] = new Array();
  currentIdChecked: string[] = new Array();
  appUsers: AppUser[] = new Array();
  roles: AppRole[] = new Array();

  constructor(
    private restService: RestService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
    private credentialsService: CredentialsService,
    private titleService: Title
  ) { }

  ngOnInit() {
    this.titleService.setTitle("Quản lý tài khoản");
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.getAllUser();
  }

  updateStatus() {
    let countChecked = 0;
    for (let i = 0; i < this.checkboxArr.length; i++) {
      if (this.checkboxArr[i]) {
        countChecked++;
      }
    }
    if (countChecked === 1) {
      this.disabledEdit = false;
    } else {
      this.disabledEdit = true;
    }
    if (countChecked > 0) {
      this.disabledDelete = false;
    } else {
      this.disabledDelete = true;
    }
    if (countChecked === this.checkboxArr.length && this.checkboxArr.length !== 0) {
      this.checkAll = true;
    } else {
      this.checkAll = false;
    }
  }

  getAllUser() {
    this.restService.getAllUser()
      .subscribe(
        (data: any) => {
          this.currentIdChecked = new Array();
          this.checkboxArr = new Array();
          this.appUsers = new Array();
          for (let i = 0; i < data.length; i++) {
            this.checkboxArr[i] = false;
            this.appUsers.push(data[i]);
            this.restService.getAllRoleOfUser(String(data[i].id))
              .subscribe(
                (data: any) => {
                  this.roles[i] = data;
                },
                () => {
                  this.dialog.open(NotifyDialogComponent, {
                    width: '350px',
                    disableClose: true,
                    autoFocus: false,
                    data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
                  });
                }
              )
          }
          this.updateStatus();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  checkUser(event: any, userId: string) {
    if (event.checked) {
      this.currentIdChecked.push(userId);
    } else {
      for (let i = 0; i < this.currentIdChecked.length; i++) {
        if (this.currentIdChecked[i] === userId) {
          this.currentIdChecked.splice(i, 1);
        }
      }
    }
    this.updateStatus();
  }

  addUser() {
    const dialogRef = this.dialog.open(AddUserDialogComponent, {
      width: '550px',
      disableClose: true,
      autoFocus: false,
      position: {top: '60px'}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        for (const user of this.appUsers) {
          if (result.username === user.userName) {
            this.dialog.open(NotifyDialogComponent, {
              width: '350px',
              disableClose: true,
              autoFocus: false,
              data: { title: "Lỗi", content: "Tên đăng nhập đã tồn tại, vui lòng thử lại" },
            });
            return;
          }
        }
        this.restService.addUser(result.username, result.password, result.fullName, result.roleName)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Thêm tài khoản thành công" },
              });
              this.getAllUser();
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
            }
          );
      }
    });
  }

  editUser() {
    const currentId = this.currentIdChecked[0];
    for (let i = 0; i < this.appUsers.length; i++) {
      if (this.appUsers[i].id === Number(currentId)) {
        const roleList: any = this.roles[i];
        for (const role of roleList) {
          if (role.roleName === Role.Root) {
            this.dialog.open(NotifyDialogComponent, {
              width: '350px',
              disableClose: true,
              autoFocus: false,
              data: { title: "Lỗi", content: "Bạn đã chọn tài khoản có quyền truy cập đặc biệt, bạn không thể sửa tài khoản này" },
            });
            return;
          }
        }
        
        const dialogRef = this.dialog.open(EditUserDialogComponent, {
          width: '550px',
          disableClose: true,
          autoFocus: false,
          position: {top: '60px'},
          data: {
            fullName: this.appUsers[i].fullName,
            roles: this.roles[i]
          }
        });

        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            this.restService.editUser(this.appUsers[i].id, result.fullName, result.password, result.roleName)
              .subscribe(
                () => {
                  this.dialog.open(NotifyDialogComponent, {
                    width: '350px',
                    disableClose: true,
                    autoFocus: false,
                    data: { title: "Thông báo", content: "Sửa tài khoản thành công" },
                  });
                  this.getAllUser();
                },
                () => {
                  this.dialog.open(NotifyDialogComponent, {
                    width: '350px',
                    disableClose: true,
                    autoFocus: false,
                    data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
                  });
                }
              );
          }
        });
        return;
      }
    }
  }

  deleteUser() {
    const dialogRef = this.dialog.open(ConfirmDeleteDialogComponent, {
      width: '350px',
      disableClose: true,
      autoFocus: false,
      data: {
        title: "Thông báo",
        content: "Bạn có muốn xóa các tài khoản này không?"
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const listUser: AppUser[] = new Array();
        for (const id of this.currentIdChecked) {
          for (let i = 0; i < this.appUsers.length; i++) {
            if (this.appUsers[i].id === Number(id)) {
              if (this.appUsers[i].userName === this.credentialsService.credentials.username) {
                this.dialog.open(NotifyDialogComponent, {
                  width: '350px',
                  disableClose: true,
                  autoFocus: false,
                  data: { title: "Lỗi", content: "Bạn đã chọn tài khoản đang đăng nhập, bạn không thể xóa tài khoản này bây giờ, vui lòng đăng nhập với tài khoản khác để xóa" },
                });
                return;
              }
              const roleList: any = this.roles[i];
              for (const role of roleList) {
                if (role.roleName === Role.Root) {
                  this.dialog.open(NotifyDialogComponent, {
                    width: '350px',
                    disableClose: true,
                    autoFocus: false,
                    data: { title: "Lỗi", content: "Bạn đã chọn tài khoản có quyền truy cập đặc biệt, bạn không thể xóa tài khoản này" },
                  });
                  return;
                }
              }
            }
          }
          listUser.push({
            id: Number(id)
          });
        }
        this.restService.deleteUsers(listUser)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Xóa tài khoản thành công" },
              });
              this.getAllUser();
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
            }
          );
      }
    });
  }

  onCheckAll(event: any) {
    for (let i = 0; i < this.checkboxArr.length; i++) {
      this.checkboxArr[i] = event.checked;
    }
    if (event.checked) {
      for (const user of this.appUsers) {
        this.currentIdChecked.push(String(user.id));
      }
    } else {
      this.currentIdChecked = new Array();
    }
    this.updateStatus();
  }
}
