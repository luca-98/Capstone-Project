import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

interface GroupData {
  reportName: string;
  groupOpenDefault: boolean;
}

@Component({
  selector: 'app-add-edit-group-dialog',
  templateUrl: './add-edit-group-dialog.component.html',
  styleUrls: ['./add-edit-group-dialog.component.scss']
})
export class AddEditGroupDialogComponent implements OnInit {
  title: string;
  groupData: GroupData;

  constructor(
    public dialogRef: MatDialogRef<AddEditGroupDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    this.title = data.title;
    this.groupData = {
      reportName: data.reportName,
      groupOpenDefault: data.groupOpenDefault
    };
  }

  ngOnInit() {
  }

  onCloseClick(): void {
    this.dialogRef.close();
  }
}
