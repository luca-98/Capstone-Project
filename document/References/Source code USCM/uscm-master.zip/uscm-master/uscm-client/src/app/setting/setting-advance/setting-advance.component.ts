import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { Title } from '@angular/platform-browser';
import { MatDialog, MatSnackBar } from '@angular/material';
import { Subscription } from 'rxjs';
import { LoaderState } from 'src/app/core/loader';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { Activity } from 'src/app/models/Activity';
import { Role } from 'src/app/models/Role';
import { ToastComponent } from 'src/app/shared/toast/toast.component';

enum Constant {
  AdminRoleId = '2',
  UserRoleId = '3',
  CanDeleteActivityId = '1',
  CanEditActivityId = '2'
}

@Component({
  selector: 'app-setting-advance',
  templateUrl: './setting-advance.component.html',
  styleUrls: ['./setting-advance.component.scss']
})
export class SettingAdvanceComponent implements OnInit {
  subscription: Subscription;
  adminCanDelete: boolean;
  userCanDelete: boolean;
  adminCanEdit: boolean;
  userCanEdit: boolean;

  constructor(
    private restService: RestService,
    private loaderService: LoaderService,
    private titleService: Title,
    private dialog: MatDialog,
    private _snackBar: MatSnackBar,
  ) { }

  ngOnInit() {
    this.titleService.setTitle("Cài đặt nâng cao");
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.loadData();
  }

  loadData() {
    this.restService.getActivityInfo()
      .subscribe(
        (res: any) => {
          this.adminCanDelete = false;
          this.userCanDelete = false;
          this.adminCanEdit = false;
          this.userCanEdit = false;

          for (const data of res) {
            if (data.key === Activity.CanDeleteCustomer) {
              for (const role of data.role) {
                if (role.roleName === Role.Admin) {
                  this.adminCanDelete = true;
                }
                if (role.roleName === Role.User) {
                  this.userCanDelete = true;
                }
              }
            }
            if (data.key === Activity.CanEditCustomer) {
              for (const role of data.role) {
                if (role.roleName === Role.Admin) {
                  this.adminCanEdit = true;
                }
                if (role.roleName === Role.User) {
                  this.userCanEdit = true;
                }
              }
            }
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  adminCanDeleteClick(event: any) {
    this.editActivityRoleRequest(Constant.CanDeleteActivityId, Constant.AdminRoleId, String(event.checked));
  }

  userCanDeleteClick(event: any) {
    this.editActivityRoleRequest(Constant.CanDeleteActivityId, Constant.UserRoleId, String(event.checked));
  }

  adminCanEditClick(event: any) {
    this.editActivityRoleRequest(Constant.CanEditActivityId, Constant.AdminRoleId, String(event.checked));
  }

  userCanEditClick(event: any) {
    this.editActivityRoleRequest(Constant.CanEditActivityId, Constant.UserRoleId, String(event.checked));
  }

  editActivityRoleRequest(activityId: string, roleId: string, status: string) {
    this.restService.editActivityRole(activityId, roleId, status)
      .subscribe(
        () => {
          this._snackBar.openFromComponent(ToastComponent, {
            duration: 2000,
            verticalPosition: 'top',
            horizontalPosition: 'end',
            data: { message: 'Cập nhật thành công' }
          });
          this.loadData();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }
}
