import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';

@Component({
  selector: 'app-additional-dialog',
  templateUrl: './additional-dialog.component.html',
  styleUrls: ['./additional-dialog.component.scss']
})
export class AdditionalDialogComponent implements OnInit {
  additionalForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<AdditionalDialogComponent>,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.additionalForm = this.formBuilder.group({
      phonenumber: [''],
      expectedDateOfBirth: [''],
      note: ['']
    });
  }

  onCloseClick(): void {
    this.dialogRef.close();
  }

  onSaveClick(): void {
    const phonenumber = this.additionalForm.get('phonenumber').value;
    if (phonenumber != '' && phonenumber.length != 10) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Bạn đã nhập sai số điện thoại" },
      });
      return;
    }
    if (!this.additionalForm.valid) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Bạn đã nhập sai ngày sinh dự kiến" },
      });
      return;
    }
    this.dialogRef.close(this.additionalForm);
  }
}
