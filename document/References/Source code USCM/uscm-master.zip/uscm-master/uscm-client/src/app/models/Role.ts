export enum Role {
    Root = 'ROLE_ROOT',
    Admin = 'ROLE_ADMIN',
    User = 'ROLE_USER'
}