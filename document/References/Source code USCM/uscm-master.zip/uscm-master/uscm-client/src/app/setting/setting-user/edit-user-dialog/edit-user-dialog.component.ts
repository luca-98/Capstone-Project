import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn, ValidationErrors } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Role } from 'src/app/models/Role';

const passwordMatchValidator: ValidatorFn = (formGroup: FormGroup): ValidationErrors | null => {
  if (formGroup.get('newPassword').value === formGroup.get('confirmNewPassword').value) {
    return null;
  } else {
    return {
      passwordMismatch: true
    };
  }
};

@Component({
  selector: 'app-edit-user-dialog',
  templateUrl: './edit-user-dialog.component.html',
  styleUrls: ['./edit-user-dialog.component.scss']
})
export class EditUserDialogComponent implements OnInit {
  formGroup: FormGroup;
  radioRole: string;

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<EditUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.radioRole = this.data.roles[0].roleName;
    this.formGroup = this.formBuilder.group({
      fullName: [this.data.fullName, [Validators.required]],
      newPassword: ['', [Validators.required]],
      confirmNewPassword: ['', [Validators.required]]
    }, { validator: passwordMatchValidator });
  }

  get newPassword() {
    return this.formGroup.get('newPassword');
  }

  get confirmNewPassword() {
    return this.formGroup.get('confirmNewPassword');
  }

  onPasswordInput() {
    if (this.formGroup.hasError('passwordMismatch')) {
      this.confirmNewPassword.setErrors([{ 'passwordMismatch': true }]);
    } else {
      this.confirmNewPassword.setErrors(null);
    }
  }

  editUser() {
    this.dialogRef.close({
      fullName: this.formGroup.get('fullName').value,
      password: this.formGroup.get('newPassword').value,
      roleName: this.radioRole
    });
  }
}
