export interface AppUser {
    id: number;
    userName?: string;
    fullName?: string;
}