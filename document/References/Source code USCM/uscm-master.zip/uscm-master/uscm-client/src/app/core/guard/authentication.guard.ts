import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, CanActivateChild } from '@angular/router';
import { CredentialsService } from '../service/credentials.service';
import { ErrorService } from 'src/app/error/error.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationGuard implements CanActivateChild {

  constructor(
    private router: Router,
    private credentialsService: CredentialsService,
    private errorService: ErrorService
  ) { }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (this.credentialsService.isAuthenticated()) {
      // check if route is restricted by role
      if (route.data.roles) {
        const userRoles = this.credentialsService.credentials.role;
        for (const routeRole of route.data.roles) {
          for (const userRole of userRoles) {
            // authorised so return true
            if (routeRole === userRole) {
              return true;
            }
          }
        }
        // role not authorised so redirect to home page
        this.errorService.setErrorCode(403);
        this.router.navigateByUrl('/error', { replaceUrl: true });
        return false;
      } else {
        // no authorization so return true
        return true;
      }
    }

    this.router.navigate(['/login'], { queryParams: { redirect: state.url }, replaceUrl: true });
    return false;
  }

}
