import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { MatDialog } from '@angular/material';
import { LoaderState } from 'src/app/core/loader';
import { Subscription } from 'rxjs';
import { EditorComponent } from 'src/app/editor/editor.component';
import { SidebarService } from 'src/app/shell/sidebar.service';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CredentialsService } from 'src/app/core/service/credentials.service';
import { Activity } from 'src/app/models/Activity';
import { ErrorService } from 'src/app/error/error.service';

declare var $: any;

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.scss']
})
export class EditCustomerComponent implements OnInit {
  customerId: string;
  subscription: Subscription;
  editForm: FormGroup;
  @ViewChild(EditorComponent, { static: false }) editor: EditorComponent;

  constructor(
    private formBuilder: FormBuilder,
    private restService: RestService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private titleService: Title,
    private sidebarService: SidebarService,
    private credentialsService: CredentialsService,
    private router: Router,
    private errorService: ErrorService
  ) {
    this.sidebarService.setSideNavOpen(false);
  }

  ngOnInit() {
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.editForm = this.formBuilder.group({
      dayVisit: [''],
      name: [''],
      phonenumber: [''],
      age: [''],
      address: [''],
      expectedDateOfBirth: [''],
      result: [''],
      note: ['']
    });
    this.route.paramMap.subscribe(params => {
      this.customerId = params.get('customerId');
      this.loadContent();
    });
    this.checkPermission();
  }

  checkPermission() {
    this.restService.getActivityInfo()
      .subscribe(
        (res: any) => {
          const currentRoleList = this.credentialsService.credentials.role;
          for (const activity of res) {
            if (activity.key === Activity.CanEditCustomer) {
              const acceptRoleList = activity.role;
              let havePermission = false;
              for (const acceptRole of acceptRoleList) {
                for (const currentRole of currentRoleList) {
                  if (currentRole === acceptRole.roleName) {
                    havePermission = true;
                    break;
                  }
                }
              }
              if (!havePermission) {
                this.errorService.setErrorCode(403);
                this.router.navigateByUrl('/error', { replaceUrl: true });
              }
              break;
            }
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  loadContent() {
    this.restService.getCustomer(this.customerId)
      .subscribe(
        (res: any) => {
          this.titleService.setTitle(res.name)
          this.editor.setContentEditor(res.report);

          const currentYear = new Date().getFullYear();
          const age = currentYear - res.yearOfBirth;
          const dayVisit = new Date(res.dayVisit);
          let expectedDateOfBirth: any;
          if (res.expectedDateOfBirth) {
            expectedDateOfBirth = new Date(res.expectedDateOfBirth);
          } else {
            expectedDateOfBirth = "";
          }

          this.editForm = this.formBuilder.group({
            dayVisit: dayVisit,
            name: res.name,
            age: age,
            address: res.address,
            expectedDateOfBirth: expectedDateOfBirth,
            result: res.result,
            note: res.note,
            phonenumber: res.phoneNumber
          });
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  print() {
    const editor = document.getElementById("editor");
    const listTable: any = editor.getElementsByTagName('table');
    for (const table of listTable) {
      $(table).colResizable({
        disable: true
      });
    }
    $("#editor").printThis({ importCSS: false });
    setTimeout(function () {
      for (const table of listTable) {
        $(table).colResizable({
          liveDrag: true,
          draggingClass: "dragging"
        });
      }
    }, 1500);
  }

  save() {
    const name = this.standardizeString(this.editForm.get('name').value);
    if (name === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập tên" },
      });
      return;
    }

    // get name search
    const nameSearch = this.removeSignAndLowerCase(name);

    const phonenumber = String(this.editForm.get('phonenumber').value).trim();
    if (phonenumber !== null && phonenumber !== 'null' && phonenumber !== "" && phonenumber.length !== 10) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Số điện thoại không đúng" },
      });
      return;
    }

    const ageStr = String(this.editForm.get('age').value).trim();
    let age = "";
    for (let i = 0; i < ageStr.length; i++) {
      const c = ageStr.substring(i, i + 1);
      if ('0123456789'.indexOf(c) !== -1) {
        age += ageStr.substring(i, i + 1);
      }
    }
    if (age === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập tuổi" },
      });
      return;
    }
    if (Number(age) <= 0 || Number(age) > 150) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Tuổi bạn nhập không hợp lệ" },
      });
      return;
    }

    // get year of birth
    const currentYear = new Date().getFullYear();
    const yearOfBirth = currentYear - Number(age);

    // get address and validate
    const address = this.standardizeString(this.editForm.get('address').value);
    if (address === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập địa chỉ" },
      });
      return;
    }

    //get address search
    const addressSearch = this.removeSignAndLowerCase(address);

    // get result and validate
    const result = this.editForm.get('result').value.trim();
    if (result === "") {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn chưa nhập kết quả" },
      });
      return;
    }

    if (!this.editForm.valid) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Thông báo", content: "Bạn đã nhập sai ngày đến khám hoặc ngày sinh dự kiến" },
      });
      return;
    }

    const dayVisit = this.convertDateToNormal(this.editForm.get('dayVisit').value);
    const expectedDateOfBirth = this.convertDateToNormal(this.editForm.get('expectedDateOfBirth').value);
    let note = "";
    if (this.editForm.get('note').value !== null) {
      note = this.editForm.get('note').value.trim();
    }
    const editor = document.getElementById('editor');
    const listTable: any = editor.getElementsByTagName('table');
    for (const table of listTable) {
      $(table).colResizable({
        disable: true
      });
    }
    this.freezeInput();
    const listTd: any = editor.getElementsByTagName("td");
    for (const tdTag of listTd) {
      if (tdTag.innerHTML === "") {
        tdTag.innerHTML = "\u00A0";
      }
    }
    const report = editor.innerHTML;

    this.restService.editCustomer(this.customerId, name, nameSearch, address, addressSearch, String(yearOfBirth),
      result, report, expectedDateOfBirth, note, dayVisit, phonenumber)
      .subscribe(
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Thông báo", content: "Sửa thông tin thành công" },
          });
          for (const table of listTable) {
            $(table).colResizable({
              liveDrag: true,
              draggingClass: "dragging"
            });
          }
          this.unFreezeInput();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
          for (const table of listTable) {
            $(table).colResizable({
              liveDrag: true,
              draggingClass: "dragging"
            });
          }
          this.unFreezeInput();
        }
      );
  }

  removeSignAndLowerCase(str: string) {
    str = str.trim();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "a");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "e");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "i");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "o");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "u");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "y");
    str = str.replace(/Đ/g, "d");
    str = str.toLowerCase();
    return str;
  }

  standardizeSpaceString(str: string) {
    str = str.trim();
    return str.replace(/\s+/g, ' ');
  }

  standardizeString(str: string) {
    str = this.standardizeSpaceString(str);
    str = str.toLowerCase();
    const temp = str.split(" ");
    str = "";
    for (let i = 0; i < temp.length; i++) {
      str += temp[i].charAt(0).toUpperCase() + temp[i].substring(1);
      if (i < temp.length - 1) {
        str += " ";
      }
    }
    return str;
  }

  // convert dateTime object to dd/MM/yyyy
  convertDateToNormal(d: any): string {
    if (!d) {
      return d;
    }
    if (d instanceof Date) {
      const date = d.getDate();
      const month = d.getMonth() + 1;
      const year = d.getFullYear();
      return date + "/" + month + "/" + year;
    } else {
      const date = d._d.getDate();
      const month = d._d.getMonth() + 1;
      const year = d._d.getFullYear();
      return date + "/" + month + "/" + year;
    }
  }

  freezeInput() {
    $('#input-name').attr("value", $('#input-name').val());
    $('#input-name').prop('readonly', true);
    $('#input-name').css("outline", "none");
    $('#input-age').attr("value", $('#input-age').val());
    $('#input-age').prop('readonly', true);
    $('#input-age').css("outline", "none");
    $('#input-address').attr("value", $('#input-address').val());
    $('#input-address').prop('readonly', true);
    $('#input-address').css("outline", "none");
    $('#input-result').html($('#input-result').val());
    $('#input-result').prop('readonly', true);
    $('#input-result').css("outline", "none");

    $('.auto-date').attr("class", "auto-date-freeze");
  }

  unFreezeInput() {
    $('#input-name').removeAttr("value");
    $('#input-name').removeAttr('readonly');
    $('#input-name').css("outline", "");
    $('#input-age').removeAttr("value");
    $('#input-age').removeAttr('readonly');
    $('#input-age').css("outline", "");
    $('#input-address').removeAttr("value");
    $('#input-address').removeAttr('readonly');
    $('#input-address').css("outline", "");
    $('#input-result').removeAttr('readonly');
    $('#input-result').css("outline", "");

    $('.auto-date-freeze').attr("class", "auto-date");
  }

}
