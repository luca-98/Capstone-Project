import { Component, OnInit, ViewChild } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';

export interface MenuPosition {
  positionX: number;
  positionY: number;
}

@Component({
  selector: 'app-context-menu',
  templateUrl: './context-menu.component.html',
  styleUrls: ['./context-menu.component.scss']
})
export class ContextMenuComponent implements OnInit {
  menuPosition: MenuPosition;
  @ViewChild(MatMenuTrigger, { static: false }) contextMenu: MatMenuTrigger;

  constructor() { }

  ngOnInit() {
    this.menuPosition = {
      positionX: 0,
      positionY: 0
    }
  }

  openMenuContext(target: any, menuPosition: MenuPosition) {
    this.menuPosition = menuPosition;
    this.contextMenu.menuData = { 'target': target };
    this.contextMenu.openMenu();
  }

  deleteTarget(target: any) {
    target.remove();
  }
}
