import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportRoutingModule } from './report-routing.module';
import { ReportComponent } from './report.component';
import { RightToolbarComponent } from './right-toolbar/right-toolbar.component';
import { EditorModule } from '../editor/editor.module';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AdditionalDialogComponent } from './additional-dialog/additional-dialog.component';
import { MatDialogModule, MatButtonModule, MatFormFieldModule, MatInputModule, MatDatepickerModule, MatNativeDateModule, MAT_DATE_LOCALE, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DATE_PICKER_FORMATS } from '../core/date-picker-formats';


@NgModule({
  declarations: [ReportComponent, RightToolbarComponent, AdditionalDialogComponent],
  imports: [
    CommonModule,
    ReportRoutingModule,
    EditorModule,
    MatTooltipModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  entryComponents: [
    AdditionalDialogComponent
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'vi-VN' },
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: DATE_PICKER_FORMATS },
    MatDatepickerModule,
  ]
})
export class ReportModule { }
