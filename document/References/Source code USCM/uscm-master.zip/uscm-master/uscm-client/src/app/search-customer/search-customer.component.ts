import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { RestService } from '../core/service/rest.service';
import { LoaderService } from '../shell/loader.service';
import { MatDialog } from '@angular/material/dialog';
import { LoaderState } from '../core/loader';
import { Subscription } from 'rxjs';
import { NotifyDialogComponent } from '../shared/dialogs/notify-dialog/notify-dialog.component';
import { Title } from '@angular/platform-browser';
import { Customer } from '../models/CustomerModel';
import { ShowReportDialogComponent } from './show-report-dialog/show-report-dialog.component';
import { ResearchService } from './research.service';

interface autoOption {
  valueDisplay: string;
  value: string;
}

@Component({
  selector: 'app-search-customer',
  templateUrl: './search-customer.component.html',
  styleUrls: ['./search-customer.component.scss']
})
export class SearchCustomerComponent implements OnInit {
  subscription: Subscription;
  searchForm: FormGroup;
  dateRangeMode = false;
  radioPickerDate: string;
  autoNameOption: autoOption[] = new Array();
  autoYearOfBirthOption: autoOption[] = new Array();
  autoAddressOption: autoOption[] = new Array();
  customers: Customer[] = new Array();
  length = 0;
  pageSize = 25;
  pageIndex = 0;
  pageSizeOptions: number[] = [25, 50, 100, 200];
  filterDateFeature = (d: Date): boolean => {
    const today = new Date();
    return d <= today;
  }

  constructor(
    private formBuilder: FormBuilder,
    private restService: RestService,
    private loaderService: LoaderService,
    private researchService: ResearchService,
    private dialog: MatDialog,
    private titleService: Title
  ) { }

  ngOnInit() {
    this.researchService.researchSubject.subscribe(() => {
      this.searchCustomer();
    });
    this.titleService.setTitle("Báo cáo siêu âm");
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.searchForm = this.formBuilder.group({
      name: [''],
      yearOfBirth: [''],
      address: [''],
      dayVisit: [''],
      dateRangeStart: [''],
      dateRangeEnd: ['']
    });
    this.radioPickerDate = "byDate";
  }

  onPickDateChange(event: any) {
    const today = new Date();
    switch (event.value) {
      case "byDate":
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: '',
          dateRangeEnd: ''
        });
        this.dateRangeMode = false;
        break;
      case "byRange":
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: '',
          dateRangeEnd: ''
        });
        this.dateRangeMode = true;
        break;
      case "today":
        this.searchForm.patchValue({
          dayVisit: today,
          dateRangeStart: '',
          dateRangeEnd: ''
        });
        this.dateRangeMode = false;
        break;
      case "last3days":
        const last3days = new Date();
        last3days.setDate(last3days.getDate() - 2);
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: last3days,
          dateRangeEnd: today
        });
        this.dateRangeMode = true;
        break;
      case "thisWeek":
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: this.getMondayOfCurrentWeek(),
          dateRangeEnd: today
        });
        this.dateRangeMode = true;
        break;
      case "thisMonth":
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: this.getFirstDateOfCurrentMonth(),
          dateRangeEnd: today
        });
        this.dateRangeMode = true;
        break;
      case "last3months":
        const last3months = new Date();
        last3months.setDate(1);
        last3months.setMonth(last3months.getMonth() - 2);
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: last3months,
          dateRangeEnd: today
        });
        this.dateRangeMode = true;
        break;
      case "thisYear":
        const firstDateOfCurrentYear = new Date(new Date().getFullYear(), 0, 1);
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: firstDateOfCurrentYear,
          dateRangeEnd: today
        });
        this.dateRangeMode = true;
        break;
      case "lastYear":
        const firstDateOfLastYear = new Date(new Date().getFullYear() - 1, 0, 1);
        const lastDateOfLastYear = new Date(new Date().getFullYear() - 1, 11, 31);
        this.searchForm.patchValue({
          dayVisit: '',
          dateRangeStart: firstDateOfLastYear,
          dateRangeEnd: lastDateOfLastYear
        });
        this.dateRangeMode = true;
        break;
    }
  }

  getMondayOfCurrentWeek() {
    const today = new Date();
    const day = today.getDay();
    const diff = today.getDate() - day + (day == 0 ? -6 : 1);
    return new Date(today.setDate(diff));
  }

  getFirstDateOfCurrentMonth() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();
    return new Date(year, month, 1);
  }

  onSingleDateChange() {
    this.radioPickerDate = "byDate";
  }

  onRangeDateChange() {
    this.radioPickerDate = "byRange";
  }

  resetInput() {
    if (this.dateRangeMode) {
      this.radioPickerDate = "byRange";
    } else {
      this.radioPickerDate = "byDate";
    }
    this.searchForm.patchValue({
      name: '',
      yearOfBirth: '',
      address: '',
      dayVisit: '',
      dateRangeStart: '',
      dateRangeEnd: ''
    });
    this.length = 0;
    this.pageSize = 25;
    this.pageIndex = 0;
    this.customers = new Array();
  }

  removeSignAndLowerCase(str: string) {
    str = str.trim();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "a");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "e");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "i");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "o");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "u");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "y");
    str = str.replace(/Đ/g, "d");
    str = str.toLowerCase();
    return str;
  }

  async generateAutoName(event: any) {
    const keyCode = event.keyCode;
    if (keyCode === 40 || keyCode === 38 || keyCode === 13) {
      return;
    }
    const value = this.searchForm.get("name").value;
    const valueSearch = this.removeSignAndLowerCase(value);
    await this.restService.searchNameCustomer(valueSearch)
      .toPromise()
      .then(
        (res: any) => {
          this.autoNameOption = new Array();
          for (const name of res) {
            const resultHighlight = this.buildHighlightString(valueSearch, name);
            this.autoNameOption.push({
              value: name,
              valueDisplay: resultHighlight
            });
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  // highlight text matching in autocomplate
  // rawString: string send to server to search
  // resultString: string result server sent to client
  buildHighlightString(rawString: string, resultString: string) {
    const resultParse = this.removeSignAndLowerCase(resultString);
    const indexStart = resultParse.indexOf(rawString);
    const indexEnd = indexStart + rawString.length;
    return "<p>" + resultString.substring(0, indexStart) + "<strong>"
      + resultString.substring(indexStart, indexEnd) + "</strong>"
      + resultString.substring(indexEnd) + "</p>";
  }

  async generateAutoYearOfBirth(event: any) {
    const keyCode = event.keyCode;
    if (keyCode === 40 || keyCode === 38 || keyCode === 13) {
      return;
    }
    const value = this.searchForm.get("yearOfBirth").value;
    await this.restService.searchYearOfBirthCustomer(value)
      .toPromise()
      .then(
        (res: any) => {
          this.autoYearOfBirthOption = new Array();
          for (let yearOfBirth of res) {
            const resultHighlight = this.buildHighlightString(value, yearOfBirth);
            this.autoYearOfBirthOption.push({
              value: yearOfBirth,
              valueDisplay: resultHighlight
            });
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  async generateAutoAddress(event: any) {
    const keyCode = event.keyCode;
    if (keyCode === 40 || keyCode === 38 || keyCode === 13) {
      return;
    }
    const value = this.searchForm.get("address").value;
    const valueSearch = this.removeSignAndLowerCase(value);
    await this.restService.searchAddressCustomer(valueSearch)
      .toPromise()
      .then(
        (res: any) => {
          this.autoAddressOption = new Array();
          for (const address of res) {
            const resultHighlight = this.buildHighlightString(valueSearch, address);
            this.autoAddressOption.push({
              value: address,
              valueDisplay: resultHighlight
            });
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  searchCustomer() {
    this.length = 0;
    this.pageSize = 25;
    this.pageIndex = 0;
    this.requestSearch(this.pageSize, this.pageIndex);
  }

  async requestSearch(pageSize: number, pageIndex: number) {
    if (this.searchForm.get('dateRangeStart').value || this.searchForm.get('dateRangeEnd').value) {
      if (!this.searchForm.get('dateRangeStart').value || !this.searchForm.get('dateRangeEnd').value ||
        this.searchForm.get('dateRangeStart').value > this.searchForm.get('dateRangeEnd').value) {
        this.dialog.open(NotifyDialogComponent, {
          width: '350px',
          disableClose: true,
          autoFocus: false,
          data: { title: "Lỗi", content: "Khoảng ngày không đúng, vui lòng chọn lại ngày" },
        });
        return;
      }
    }
    const nameSearch = this.removeSignAndLowerCase(this.searchForm.get('name').value);
    const addressSearch = this.removeSignAndLowerCase(this.searchForm.get('address').value);
    let yearOfBirth = this.searchForm.get('yearOfBirth').value;
    if (yearOfBirth) {
      if (yearOfBirth < 100) {
        const currentYear = new Date().getFullYear();
        yearOfBirth = currentYear - yearOfBirth;
      }
    }
    await this.restService.searchCustomer(nameSearch, yearOfBirth, addressSearch,
      this.convertDateToNormal(this.searchForm.get('dayVisit').value),
      this.convertDateToNormal(this.searchForm.get('dateRangeStart').value),
      this.convertDateToNormal(this.searchForm.get('dateRangeEnd').value), pageSize, pageIndex)
      .toPromise()
      .then(
        (res: any) => {
          this.length = res.totalRecord;
          this.pageSize = res.pageSize;
          this.pageIndex = res.pageIndex;
          this.customers = new Array();
          if (this.length === 0) {
            this.dialog.open(NotifyDialogComponent, {
              width: '350px',
              disableClose: true,
              autoFocus: false,
              data: { title: "Thông báo", content: "Không tìm thấy bất kì kết quả nào" },
            });
          }
          const listCustomer = res.customerEntityList;
          for (const customer of listCustomer) {
            const currentYear = new Date().getFullYear();
            const age = currentYear - customer.yearOfBirth;
            let dayVisit = this.convertDateToDisplay(new Date(customer.dayVisit));
            let expectedDateOfBirth = "";
            if (customer.expectedDateOfBirth) {
              expectedDateOfBirth = this.convertDateToDisplay(new Date(customer.expectedDateOfBirth));
            }
            this.customers.push({
              id: customer.id,
              dayVisit: dayVisit,
              name: customer.name,
              age: age.toString(),
              address: customer.address,
              expectedDateOfBirth: expectedDateOfBirth,
              result: customer.result,
              note: customer.note,
              phonenumber: customer.phoneNumber
            });
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  // convert dateTime object to dd/MM/yyyy
  convertDateToNormal(d: any): string {
    if (!d) {
      return d;
    }
    const date = d.getDate();
    const month = d.getMonth() + 1;
    const year = d.getFullYear();
    return date + "/" + month + "/" + year;
  }

  // convert dateTime object to dd/MM/yy
  convertDateToDisplay(d: any): string {
    if (!d) {
      return d;
    }
    const date = d.getDate();
    const month = d.getMonth() + 1;
    const year = d.getFullYear().toString().substring(2, 4);
    return date + "/" + month + "/" + year;
  }

  onPageEvent(event: any) {
    this.requestSearch(event.pageSize, event.pageIndex);
  }

  async loadReportDetail(id: string) {
    await this.restService.getCustomerReport(id)
      .toPromise()
      .then(
        (res: any) => {
          if (res === null) {
            this.dialog.open(NotifyDialogComponent, {
              width: '350px',
              disableClose: true,
              autoFocus: false,
              data: { title: "Thông báo", content: "Không có nội dung báo cáo để hiển thị" },
            });
            return;
          }
          this.dialog.open(ShowReportDialogComponent, {
            width: '825px',
            height: '100%',
            data: {
              id: id,
              content: res
            },
          });
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }
}
