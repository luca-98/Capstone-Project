export enum Activity {
    CanDeleteCustomer = 'CAN_DELETE_CUSTOMER',
    CanEditCustomer = 'CAN_EDIT_CUSTOMER'
}