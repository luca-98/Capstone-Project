import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { RestService } from '../core/service/rest.service';
import { LoaderState } from '../core/loader';
import { LoaderService } from '../shell/loader.service';
import { EditorComponent } from '../editor/editor.component';
import { ActivatedRoute, Router } from '@angular/router';
import { NotifyDialogComponent } from '../shared/dialogs/notify-dialog/notify-dialog.component';
import { Title } from '@angular/platform-browser';
import { RightToolbarComponent } from './right-toolbar/right-toolbar.component';
import { ReportForm } from '../models/ReportFormModel';
import { ErrorService } from '../error/error.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
  activeReportId: string;
  subscription: Subscription;
  @ViewChild(EditorComponent, { static: false }) editor: EditorComponent;
  @ViewChild(RightToolbarComponent, { static: false }) rightToolbar: RightToolbarComponent;

  constructor(
    private restService: RestService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private titleService: Title,
    private router: Router,
    private errorService: ErrorService
  ) { }

  ngOnInit() {
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.route.paramMap.subscribe(params => {
      this.activeReportId = params.get('reportId');
      this.loadContent();
    });
  }

  loadContent() {
    this.restService.getReport(this.activeReportId)
      .subscribe(
        (data: ReportForm) => {
          if (data.groupFlag) {
            this.errorService.setErrorCode(404);
            this.router.navigateByUrl('/error', { replaceUrl: true });
          }
          this.titleService.setTitle(data.reportName);
          this.editor.setContentEditor(data.content);
          this.rightToolbar.changeNeedSaveFlag(false);
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

}
