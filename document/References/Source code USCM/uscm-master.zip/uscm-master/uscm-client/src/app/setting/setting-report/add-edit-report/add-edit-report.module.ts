import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddEditReportRoutingModule } from './add-edit-report-routing.module';
import { AddEditReportComponent } from './add-edit-report.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { EditorModule } from 'src/app/editor/editor.module';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { ContextMenuComponent } from './context-menu/context-menu.component';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';

@NgModule({
  declarations: [AddEditReportComponent, ContextMenuComponent],
  imports: [
    CommonModule,
    AddEditReportRoutingModule,
    MatCardModule,
    MatFormFieldModule,
    EditorModule,
    MatTooltipModule,
    MatInputModule,
    MatButtonModule,
    MatMenuModule,
    FormsModule,
    MatSelectModule,
  ]
})
export class AddEditReportModule { }
