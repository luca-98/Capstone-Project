import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { CredentialsService } from '../core/service/credentials.service';
import { Role } from '../models/Role';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent implements OnInit {
  isShowSettingUser: boolean;
  isShowSettingAdvance: boolean;

  constructor(
    private titleService: Title,
    private credentialsService: CredentialsService
  ) { }

  ngOnInit() {
    this.titleService.setTitle("Cài đặt");
    const currentUserRoles = this.credentialsService.credentials.role;
    for (const role of currentUserRoles) {
      if (role === Role.Root || role === Role.Admin) {
        this.isShowSettingUser = true;
      }
      if (role === Role.Root) {
        this.isShowSettingAdvance = true;
      }
    }
  }

}
