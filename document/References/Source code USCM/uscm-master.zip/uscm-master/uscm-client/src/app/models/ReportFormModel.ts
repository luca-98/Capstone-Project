export interface ReportForm {
    id: string;
    reportName?: string;
    orderNumber?: number;
    content?: string;
    lastEdit?: string;
    groupFlag?: boolean;
    parentGroup?: ReportForm;
    groupOpenDefault?: boolean;
}