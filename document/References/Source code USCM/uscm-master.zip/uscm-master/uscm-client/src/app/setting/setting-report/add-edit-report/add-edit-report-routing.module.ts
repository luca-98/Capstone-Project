import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddEditReportComponent } from './add-edit-report.component';

const routes: Routes = [
  { path: '', component: AddEditReportComponent },
  { path: ':reportId', component: AddEditReportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddEditReportRoutingModule { }
