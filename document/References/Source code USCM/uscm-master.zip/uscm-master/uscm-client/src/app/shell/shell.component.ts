import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { RestService } from '../core/service/rest.service';
import { LoaderState } from '../core/loader';
import { ReportForm } from '../models/ReportFormModel';
import { AuthenticationService } from '../core/service/authentication.service';
import { Router, NavigationEnd } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { SidebarService } from './sidebar.service';
import { LoaderService } from './loader.service';
import { NotifyDialogComponent } from '../shared/dialogs/notify-dialog/notify-dialog.component';
import { CredentialsService } from '../core/service/credentials.service';
import { ChangePasswordDialogComponent } from '../shared/dialogs/change-password-dialog/change-password-dialog.component';

interface ReportFormShell extends ReportForm {
  childrens?: ReportFormShell[];
  groupOpen?: boolean;
}

@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss']
})
export class ShellComponent implements OnInit {
  currentUserFullName: string;
  sideNavOpened = true;
  showLoader = false;
  subscription: Subscription;
  reportForms: ReportFormShell[] = new Array();
  activeReportId: string;

  constructor(
    private restService: RestService,
    private authentiactionService: AuthenticationService,
    private sidebarService: SidebarService,
    private loaderService: LoaderService,
    private router: Router,
    private dialog: MatDialog,
    private credentialsService: CredentialsService,
    private changeDetectorRef: ChangeDetectorRef
  ) {
    // detect id on url and active item in sidebar or disable if not report page
    this.router.events.subscribe(value => {
      if (value instanceof NavigationEnd) {
        if (value.url.includes("/report/")) {
          const uuidRegex = new RegExp("^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$");
          const valueUrl = value.url.substring(8, 44);
          if (uuidRegex.test(valueUrl)) {
            this.activeReportId = value.url.substring(8, 44);
          } else {
            this.activeReportId = undefined;
          }
        } else {
          this.activeReportId = undefined;
        }
      }
    });
    this.loaderService.showLoaderSubject.subscribe((value: boolean) => {
      this.showLoader = value;
      changeDetectorRef.detectChanges();
    });
    this.sidebarService.sideNavOpenChange.subscribe((value: boolean) => {
      this.sideNavOpened = value;
    });
    this.sidebarService.reloadDataSidebarChange.subscribe(() => {
      this.getAllReport();
    });
  }

  ngOnInit() {
    this.currentUserFullName = this.credentialsService.credentials.fullname;
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );

    this.getAllReport();
  }

  logout() {
    this.authentiactionService.logout();
    this.router.navigate(['login']);
  }

  getAllReport() {
    this.restService.getAllReport()
      .subscribe(
        (data: any) => {
          this.reportForms = new Array();
          for (const report of data) {
            if (report.parentGroup !== null) {
              continue;
            }
            const childrens: ReportFormShell[] = new Array();
            if (report.groupFlag) {
              for (const r of data) {
                if (r.parentGroup !== null && r.parentGroup.id === report.id) {
                  const rp = <ReportFormShell>{
                    id: r.id,
                    reportName: r.reportName,
                    orderNumber: r.orderNumber,
                    groupFlag: r.groupFlag
                  };
                  childrens.push(rp);
                }
                childrens.sort((a: any, b: any) =>
                  (a.orderNumber > b.orderNumber) ? 1 : ((b.orderNumber > a.orderNumber) ? -1 : 0)
                );
              }
            }
            const rp = <ReportFormShell>{
              id: report.id,
              reportName: report.reportName,
              orderNumber: report.orderNumber,
              groupFlag: report.groupFlag,
              childrens: childrens,
              groupOpen: report.groupOpenDefault
            };
            this.reportForms.push(rp);
          }
          // sort by orderNumber
          this.reportForms.sort((a: any, b: any) =>
            (a.orderNumber > b.orderNumber) ? 1 : ((b.orderNumber > a.orderNumber) ? -1 : 0)
          );
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  changePassword() {
    const dialogRef = this.dialog.open(ChangePasswordDialogComponent, {
      width: '500px',
      disableClose: true,
      autoFocus: false,
      position: { top: '70px' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.restService.changePassword(result.oldPassword, result.newPassword)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Đổi mật khẩu thành công" },
              });
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Thực hiện thao tác không thành công, vui lòng thử lại" },
              });
            }
          )
      }
    });
  }

}
