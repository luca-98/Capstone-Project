import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SearchCustomerComponent } from './search-customer.component';

const routes: Routes = [
  { path: '', component: SearchCustomerComponent }, 
  { path: 'edit-customer', loadChildren: () => import('./edit-customer/edit-customer.module').then(m => m.EditCustomerModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SearchCustomerRoutingModule { }
