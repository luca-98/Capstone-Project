export interface AppRole {
    id: number;
    roleName: String;
}