export interface Customer {
    id: string;
    name: string;
    age: string;
    address: string;
    dayVisit: string;
    expectedDateOfBirth: string;
    result: string;
    note: string;
    phonenumber: string;
}