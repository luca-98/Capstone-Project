import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { RestService } from '../core/service/rest.service';
import { NotifyDialogComponent } from '../shared/dialogs/notify-dialog/notify-dialog.component';

@Component({
  selector: 'app-customer-report',
  templateUrl: './customer-report.component.html',
  styleUrls: ['./customer-report.component.scss']
})
export class CustomerReportComponent implements OnInit {
  customerId: string;

  constructor(
    private restService: RestService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.customerId = params.get('customerId');
      this.loadContent();
    });
  }

  loadContent() {
    this.restService.getCustomer(this.customerId)
      .subscribe(
        (res: any) => {
          this.titleService.setTitle(res.name)
          if (res.report === null) {
            this.dialog.open(NotifyDialogComponent, {
              width: '350px',
              disableClose: true,
              autoFocus: false,
              data: { title: "Thông báo", content: "Không có nội dung báo cáo để hiển thị" },
            });
            return;
          }
          document.getElementById('editor').innerHTML = res.report;
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }
}
