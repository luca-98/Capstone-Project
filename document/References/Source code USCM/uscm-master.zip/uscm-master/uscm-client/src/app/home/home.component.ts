import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { RestService } from '../core/service/rest.service';
import { LoaderService } from '../shell/loader.service';
import { Subscription } from 'rxjs';
import { LoaderState } from '../core/loader';
import { MatDialog } from '@angular/material';
import { NotifyDialogComponent } from '../shared/dialogs/notify-dialog/notify-dialog.component';
import { ChartComponent } from 'angular2-chartjs';

interface SelectOption {
  value: number;
  viewValue: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  subscription: Subscription;
  @ViewChild('chartDougnut', { static: false }) chartDougnut: ChartComponent;
  @ViewChild('chartLine', { static: false }) chartLine: ChartComponent;

  totalInSystem: number;

  totalToday: number;
  ratioDate: number;
  isIncreaseInDate: boolean;

  totalThisWeek: number;
  ratioWeek: number;
  isIncreaseInWeek: boolean;

  totalThisMonth: number;
  ratioMonth: number;
  isIncreaseInMonth: boolean;

  totalThisYear: number;
  ratioYear: number;
  isIncreaseInYear: boolean;

  chartMode = 2;
  viewCharModeOption: SelectOption[] = [
    {
      value: 1,
      viewValue: 'Năm qua'
    },
    {
      value: 2,
      viewValue: 'Tháng qua'
    },
    {
      value: 3,
      viewValue: 'Tuần qua'
    }
  ];

  dataObjectDoughnut = {
    labels: ["Hôm qua", "Hôm nay"],
    datasets: [
      {
        data: [0, 0],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)'
        ],
        borderWidth: 1
      }
    ]
  };
  optionsDoughnutChart = {
    responsive: true,
    maintainAspectRatio: false,
    tooltips: {
      mode: 'index',
      intersect: false,
    },
  };
  optionsLineChart = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        }
      }]
    },
    legend: {
      display: false
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
    hover: {
      mode: 'nearest',
      intersect: true
    },
  };

  dataObjectLine = {
    labels: [],
    datasets: [
      {
        label: "",
        data: [],
        backgroundColor: [
          'rgba(54, 162, 235, 0.2)'
        ],
        borderColor: [
          'rgba(54, 162, 235, 1)'
        ]
      }
    ]
  }

  labelsRangeYear = [];
  labelsRangeMonth = [];
  labelsRangeWeek = [];

  dataRangeYear = [];
  dataRangeMonth = [];
  dataRangeWeek = [];

  constructor(
    private titleService: Title,
    private restService: RestService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.titleService.setTitle("Quản lý phòng khám");
    this.loadData();
  }

  loadData() {
    this.restService.getCustomerSummary()
      .subscribe(
        (data: any) => {
          this.totalInSystem = data.totalInSystem;

          this.totalToday = data.today;
          this.isIncreaseInDate = data.today > data.yesterday;
          if (data.today > data.yesterday) {
            this.ratioDate = (data.today - data.yesterday) / data.today * 100;
          } else {
            this.ratioDate = (data.yesterday - data.today) / data.yesterday * 100;
          }
          this.ratioDate = +this.ratioDate.toFixed(1);
          this.dataObjectDoughnut.datasets[0].data = [data.yesterday, data.today];
          this.chartDougnut.chart.update();

          this.totalThisWeek = data.thisWeek;
          this.isIncreaseInWeek = data.thisWeek > data.lastWeek;
          if (data.thisWeek > data.lastWeek) {
            this.ratioWeek = (data.thisWeek - data.lastWeek) / data.thisWeek * 100;
          } else {
            this.ratioWeek = (data.lastWeek - data.thisWeek) / data.lastWeek * 100;
          }
          this.ratioWeek = +this.ratioWeek.toFixed(1);

          this.totalThisMonth = data.thisMonth;
          this.isIncreaseInMonth = data.thisMonth > data.lastMonth;
          if (data.thisMonth > data.lastMonth) {
            this.ratioMonth = (data.thisMonth - data.lastMonth) / data.thisMonth * 100;
          } else {
            this.ratioMonth = (data.lastMonth - data.thisMonth) / data.lastMonth * 100;
          }
          this.ratioMonth = +this.ratioMonth.toFixed(1);

          this.totalThisYear = data.thisYear;
          this.isIncreaseInYear = data.thisYear > data.lastYear;
          if (data.thisYear > data.lastYear) {
            this.ratioYear = (data.thisYear - data.lastYear) / data.thisYear * 100;
          } else {
            this.ratioYear = (data.lastYear - data.thisYear) / data.lastYear * 100;
          }
          this.ratioYear = +this.ratioYear.toFixed(1);

          const rangeYear = data.rangeYear;
          rangeYear.sort((a: any, b: any) => (
            a.index < b.index) ? 1 : ((b.index < a.index) ? -1 : 0)
          );
          for (const item of rangeYear) {
            this.labelsRangeYear.push(item.time);
            this.dataRangeYear.push(item.value);
          }

          const rangeMonth = data.rangeMonth;
          rangeMonth.sort((a: any, b: any) => (
            a.index < b.index) ? 1 : ((b.index < a.index) ? -1 : 0)
          );
          for (const item of rangeMonth) {
            this.labelsRangeMonth.push(item.time);
            this.dataRangeMonth.push(item.value);
          }

          const rangeWeek = data.rangeWeek;
          rangeWeek.sort((a: any, b: any) => (
            a.index < b.index) ? 1 : ((b.index < a.index) ? -1 : 0)
          );
          for (const item of rangeWeek) {
            let label: string;
            switch (item.time) {
              case "1":
                label = "Chủ nhật"
                break;
              case "2":
                label = "Thứ hai"
                break;
              case "3":
                label = "Thứ ba"
                break;
              case "4":
                label = "Thứ tư"
                break;
              case "5":
                label = "Thứ năm"
                break
              case "6":
                label = "Thứ sáu"
                break;
              case "7":
                label = "Thứ bảy"
                break;
            }
            this.labelsRangeWeek.push(label);
            this.dataRangeWeek.push(item.value);
          }

          this.changeChartMode();
          this.chartLine.chart.update();
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  changeChartMode() {
    switch (this.chartMode) {
      case 1:
        this.dataObjectLine.datasets[0].label = "Số ca đến khám trong tháng";
        this.dataObjectLine.labels = this.labelsRangeYear;
        this.dataObjectLine.datasets[0].data = this.dataRangeYear;
        break;
      case 2:
        this.dataObjectLine.datasets[0].label = "Số ca đến khám trong ngày";
        this.dataObjectLine.labels = this.labelsRangeMonth;
        this.dataObjectLine.datasets[0].data = this.dataRangeMonth;
        break;
      case 3:
        this.dataObjectLine.datasets[0].label = "Số ca đến khám trong ngày";
        this.dataObjectLine.labels = this.labelsRangeWeek;
        this.dataObjectLine.datasets[0].data = this.dataRangeWeek;
        break;
    }
    this.chartLine.chart.update();
  }
}
