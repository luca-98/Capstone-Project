import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Subject } from 'rxjs';
import { LoaderState } from '../loader';
import { ReportForm } from 'src/app/models/ReportFormModel';
import { AppUser } from 'src/app/models/UserModel';

@Injectable({
  providedIn: 'root'
})
export class RestService {
  loaderSubject = new Subject<LoaderState>();
  loaderState = this.loaderSubject.asObservable();

  private changePasswordUrl = environment.apiUrl + "/change-password/";
  private reportApiUrl = environment.apiUrl + "/reports/";
  private userApiUrl = environment.apiUrl + "/users/";
  private customerApiUrl = environment.apiUrl + "/customer/";
  private activityApiUrl = environment.apiUrl + "/activity/";

  constructor(
    private _http: HttpClient
  ) { }

  show() {
    this.loaderSubject.next(<LoaderState>{ show: true });
  }
  hide() {
    this.loaderSubject.next(<LoaderState>{ show: false });
  }

  changePassword(oldPassword: string, newPassword: string) {
    const formData = new FormData();
    formData.append('oldPassword', oldPassword);
    formData.append('newPassword', newPassword);
    return this._http.post(this.changePasswordUrl, formData);
  }

  getAllReport() {
    return this._http.get(this.reportApiUrl);
  }

  getReport(reportId: string) {
    const url = this.reportApiUrl + reportId;
    return this._http.get(url);
  }

  deleteReports(listReport: ReportForm[]) {
    const url = this.reportApiUrl + "delete-reports";
    return this._http.request('delete', url, { body: listReport });
  }

  updateReports(listReport: ReportForm[]) {
    return this._http.put(this.reportApiUrl, listReport);
  }

  updateReport(idReport: string, reportName: string, content: string, groupFlag: string, parentId: string, groupOpenDefault: string) {
    const url = this.reportApiUrl + idReport;
    const formData = new FormData();
    formData.append('groupFlag', groupFlag);
    formData.append('reportName', reportName);
    if (groupFlag === "false") {
      formData.append('content', content);
      if (parentId !== null && parentId !== undefined) {
        formData.append('parentId', parentId);
      }
    }
    if (groupFlag === "true") {
      formData.append('groupOpenDefault', groupOpenDefault);
    }
    return this._http.put(url, formData);
  }

  addReport(reportName: string, content: string, groupFlag: string, parentId: string, groupOpenDefault: string) {
    const formData = new FormData();
    formData.append('groupFlag', groupFlag);
    formData.append('reportName', reportName);
    if (groupFlag === "false") {
      formData.append('content', content);
      if (parentId !== null) {
        formData.append('parentId', parentId);
      }
    }
    if (groupFlag === "true") {
      formData.append('groupOpenDefault', groupOpenDefault);
    }
    return this._http.post(this.reportApiUrl, formData);
  }

  getAllUser() {
    return this._http.get(this.userApiUrl);
  }

  getAllRoleOfUser(userId: string) {
    const url = this.userApiUrl + userId + "/roles";
    return this._http.get(url);
  }

  deleteUsers(listUser: AppUser[]) {
    const url = this.userApiUrl + "delete-users";
    return this._http.request('delete', url, { body: listUser });
  }

  addUser(username: string, password: string, fullName: string, roleName: string) {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    formData.append('fullName', fullName);
    formData.append('roleName', roleName);
    return this._http.post(this.userApiUrl, formData);
  }

  editUser(userId: number, fullName: string, password: string, roleName: string) {
    const url = this.userApiUrl + userId;
    const formData = new FormData();
    formData.append('fullName', fullName);
    formData.append('password', password);
    formData.append('roleName', roleName);
    return this._http.put(url, formData);
  }

  searchNameCustomer(value: string) {
    const url = this.customerApiUrl + "search-name-auto";
    const params = new HttpParams().set('value', value);
    return this._http.get(url, { params: params });
  }

  searchYearOfBirthCustomer(value: string) {
    const url = this.customerApiUrl + "search-year-of-birth-auto";
    const params = new HttpParams().set('value', value);
    return this._http.get(url, { params: params });
  }

  searchAddressCustomer(value: string) {
    const url = this.customerApiUrl + "search-address-auto";
    const params = new HttpParams().set('value', value);
    return this._http.get(url, { params: params });
  }

  searchCustomer(nameSearch: string, yearOfBirth: string, addressSearch: string,
    dayVisit: string, dateRangeStart: string, dateRangeEnd: string, pageSize: any, pageIndex: any) {
    const url = this.customerApiUrl + "search-customer";
    let params = new HttpParams()
      .set('nameSearch', nameSearch)
      .set('yearOfBirth', yearOfBirth)
      .set('addressSearch', addressSearch)
      .set('pageSize', pageSize)
      .set('pageIndex', pageIndex);
    if (dayVisit !== "") {
      params = params.set('dayVisit', dayVisit);
    }
    if (dateRangeStart !== "") {
      params = params.set('dateRangeStart', dateRangeStart);
    }
    if (dateRangeEnd !== "") {
      params = params.set('dateRangeEnd', dateRangeEnd);
    }
    return this._http.get(url, { params: params });
  }

  getCustomer(customerId: string) {
    const url = this.customerApiUrl + customerId;
    return this._http.get(url);
  }

  getCustomerReport(customerId: string) {
    const url = this.customerApiUrl + "customer-report/" + customerId;
    return this._http.get(url);
  }

  addCustomer(name: string, nameSearch: string, address: string, addressSearch: string,
    yearOfBirth: string, result: string, report: string, phonenumber:string, expectedDateOfBirth: string, note: string) {
    const formData = new FormData();
    formData.append('name', name);
    formData.append('nameSearch', nameSearch);
    formData.append('address', address);
    formData.append('addressSearch', addressSearch);
    formData.append('yearOfBirth', yearOfBirth);
    formData.append('result', result);
    formData.append('report', report);
    if (phonenumber !== "") {
      formData.append('phonenumber', phonenumber);
    }
    if (expectedDateOfBirth !== "") {
      formData.append('expectedDateOfBirth', expectedDateOfBirth);
    }
    if (note !== "") {
      formData.append('note', note);
    }

    return this._http.post(this.customerApiUrl, formData);
  }

  deleteCustomer(id: string) {
    const url = this.customerApiUrl + id;
    return this._http.request('delete', url);
  }

  editCustomer(id: string, name: string, nameSearch: string, address: string, addressSearch: string,
    yearOfBirth: string, result: string, report: string, expectedDateOfBirth: string, note: string, dayVisit: string, phonenumber: string) {
    const url = this.customerApiUrl + id;
    const formData = new FormData();
    formData.append('dayVisit', dayVisit);
    formData.append('name', name);
    formData.append('nameSearch', nameSearch);
    formData.append('address', address);
    formData.append('addressSearch', addressSearch);
    formData.append('yearOfBirth', yearOfBirth);
    formData.append('result', result);
    formData.append('report', report);
    if (expectedDateOfBirth !== "") {
      formData.append('expectedDateOfBirth', expectedDateOfBirth);
    }
    if (note !== "") {
      formData.append('note', note);
    }
    if (phonenumber !== "") {
      formData.append('phonenumber', phonenumber);
    }

    return this._http.put(url, formData);
  }

  getActivityInfo() {
    const url = this.activityApiUrl + "info";
    return this._http.get(url);
  }

  editActivityRole(activityId: string, roleId: string, status: string) {
    const url = this.activityApiUrl;
    const formData = new FormData();
    formData.append('activityId', activityId);
    formData.append('roleId', roleId);
    formData.append('status', status);
    return this._http.put(url, formData);
  }

  getCustomerSummary() {
    const url = this.customerApiUrl + "summary";
    return this._http.get(url);
  }
}
