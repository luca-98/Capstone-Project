import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormBuilder, ValidatorFn, ValidationErrors, Validators } from '@angular/forms';
import { Role } from 'src/app/models/Role';

const passwordMatchValidator: ValidatorFn = (formGroup: FormGroup): ValidationErrors | null => {
  if (formGroup.get('newPassword').value === formGroup.get('confirmNewPassword').value) {
    return null;
  } else {
    return {
      passwordMismatch: true
    };
  }
};

@Component({
  selector: 'app-add-user-dialog',
  templateUrl: './add-user-dialog.component.html',
  styleUrls: ['./add-user-dialog.component.scss']
})
export class AddUserDialogComponent implements OnInit {
  formGroup: FormGroup;
  radioRole: string;

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<AddUserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.radioRole = Role.User;
    this.formGroup = this.formBuilder.group({
      username: ['', [Validators.required]],
      fullName: ['', [Validators.required]],
      newPassword: ['', [Validators.required]],
      confirmNewPassword: ['', [Validators.required]]
    }, { validator: passwordMatchValidator });
  }

  get newPassword() {
    return this.formGroup.get('newPassword');
  }

  get confirmNewPassword() {
    return this.formGroup.get('confirmNewPassword');
  }

  onPasswordInput() {
    if (this.formGroup.hasError('passwordMismatch')) {
      this.confirmNewPassword.setErrors([{ 'passwordMismatch': true }]);
    } else {
      this.confirmNewPassword.setErrors(null);
    }
  }

  addUser() {
    this.dialogRef.close({
      username: this.formGroup.get('username').value,
      password: this.formGroup.get('newPassword').value,
      fullName: this.formGroup.get('fullName').value,
      roleName: this.radioRole
    });
  }
}
