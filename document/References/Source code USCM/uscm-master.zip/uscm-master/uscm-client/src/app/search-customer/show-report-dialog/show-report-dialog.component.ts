import { Component, Inject, AfterViewInit, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { ConfirmDeleteDialogComponent } from 'src/app/shared/dialogs/confirm-delete-dialog/confirm-delete-dialog.component';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { RestService } from 'src/app/core/service/rest.service';
import { ResearchService } from '../research.service';
import { Activity } from 'src/app/models/Activity';
import { CredentialsService } from 'src/app/core/service/credentials.service';

declare var $: any;

@Component({
  selector: 'app-show-report-dialog',
  templateUrl: './show-report-dialog.component.html',
  styleUrls: ['./show-report-dialog.component.scss']
})
export class ShowReportDialogComponent implements OnInit, AfterViewInit {
  showReportContainer: any;
  id: string;
  content: string;
  canEdit = false;
  canDelete = false;

  constructor(
    public dialogRef: MatDialogRef<ShowReportDialogComponent>,
    private dialog: MatDialog,
    private restService: RestService,
    private researchService: ResearchService,
    private credentialsService: CredentialsService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.content = data.content;
    this.id = data.id;
  }

  ngOnInit(): void {
    this.checkPermission();
    this.showReportContainer = document.getElementById('show-report-container');
  }

  ngAfterViewInit() {
    this.showReportContainer.innerHTML = this.content;
  }

  checkPermission() {
    this.restService.getActivityInfo()
      .subscribe(
        (res: any) => {
          const currentRoleList = this.credentialsService.credentials.role;
          for (const activity of res) {
            if (activity.key === Activity.CanEditCustomer) {
              const acceptRoleList = activity.role;
              for (const acceptRole of acceptRoleList) {
                for (const currentRole of currentRoleList) {
                  if (currentRole === acceptRole.roleName) {
                    this.canEdit = true;
                    break;
                  }
                }
              }
            }
            if (activity.key === Activity.CanDeleteCustomer) {
              const acceptRoleList = activity.role;
              for (const acceptRole of acceptRoleList) {
                for (const currentRole of currentRoleList) {
                  if (currentRole === acceptRole.roleName) {
                    this.canDelete = true;
                    break;
                  }
                }
              }
            }
          }
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
          });
        }
      )
  }

  print() {
    $("#show-report-container").printThis({ importCSS: false });
  }

  delete() {
    const dialogRef = this.dialog.open(ConfirmDeleteDialogComponent, {
      width: '350px',
      disableClose: true,
      autoFocus: false,
      data: {
        title: "Thông báo",
        content: "Bạn có muốn xóa các kết quả này không?"
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.restService.deleteCustomer(this.id)
          .subscribe(
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Thông báo", content: "Xóa kết quả thành công" },
              });
              this.dialogRef.close();
              this.researchService.research();
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
              });
            }
          )
      }
    });
  }

  onEdit() {
    this.dialogRef.close();
  }

  openInNewWindows() {
    const url = document.location.origin + '/customer-report/' + this.id;
    this.popupCenter(url, 'Báo cáo chi tiết', 800, 2000);
    this.dialogRef.close();
  }

  popupCenter(url: string, title: string, w: number, h: number) {
    // Fixes dual-screen position
    const dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
    const dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;

    const width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    const height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    const left = ((width / 2) - (w / 2)) + dualScreenLeft;
    const top = ((height / 2) - (h / 2)) + dualScreenTop;
    const newWindow = window.open(url, title, 'scrollbars=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);

    // Puts focus on the newWindow
    if (window.focus) {
      newWindow.focus();
    }
  }
}
