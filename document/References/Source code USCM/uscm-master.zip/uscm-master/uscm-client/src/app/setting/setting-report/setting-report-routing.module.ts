import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SettingReportComponent } from './setting-report.component';

const routes: Routes = [
  { path: '', component: SettingReportComponent },
  { path: 'add', loadChildren: () => import('./add-edit-report/add-edit-report.module').then(m => m.AddEditReportModule) },
  { path: 'edit', loadChildren: () => import('./add-edit-report/add-edit-report.module').then(m => m.AddEditReportModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingReportRoutingModule { }
