import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingReportRoutingModule } from './setting-report-routing.module';
import { SettingReportComponent } from './setting-report.component';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { AddEditGroupDialogComponent } from './add-edit-group-dialog/add-edit-group-dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';


@NgModule({
  declarations: [SettingReportComponent, AddEditGroupDialogComponent],
  imports: [
    CommonModule,
    SettingReportRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatCheckboxModule,
    FormsModule,
    MatTooltipModule,
    MatMenuModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSlideToggleModule
  ],
  entryComponents: [
    AddEditGroupDialogComponent
  ]
})
export class SettingReportModule { }
