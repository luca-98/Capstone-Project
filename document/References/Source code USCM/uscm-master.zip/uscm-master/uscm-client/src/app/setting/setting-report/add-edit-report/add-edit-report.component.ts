import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SidebarService } from 'src/app/shell/sidebar.service';
import { EditorComponent } from 'src/app/editor/editor.component';
import { ContextMenuComponent } from './context-menu/context-menu.component';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { RestService } from 'src/app/core/service/rest.service';
import { LoaderService } from 'src/app/shell/loader.service';
import { LoaderState } from 'src/app/core/loader';
import { ConfirmDialogComponent } from 'src/app/shared/dialogs/confirm-dialog/confirm-dialog.component';
import { NotifyDialogComponent } from 'src/app/shared/dialogs/notify-dialog/notify-dialog.component';
import { ReportForm } from 'src/app/models/ReportFormModel';
import { Title } from '@angular/platform-browser';
import { ErrorService } from 'src/app/error/error.service';

declare var $: any;

@Component({
  selector: 'app-add-edit-report',
  templateUrl: './add-edit-report.component.html',
  styleUrls: ['./add-edit-report.component.scss']
})
export class AddEditReportComponent implements OnInit {
  titleScreen: string;
  editor: any;
  currentId: string;
  isEdit = false;
  subscription: Subscription;
  newReportName: string;
  parentGroup: string = null;
  groups: ReportForm[] = new Array();
  @ViewChild(EditorComponent, { static: false }) editorComponent: EditorComponent;
  @ViewChild(ContextMenuComponent, { static: false }) contextMenu: ContextMenuComponent;

  constructor(
    private sidebarService: SidebarService,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private restService: RestService,
    private loaderService: LoaderService,
    private titleService: Title,
    private router: Router,
    private errorService: ErrorService
  ) {
    this.sidebarService.setSideNavOpen(false);
  }

  ngOnInit() {
    this.loadGroup();
    this.subscription = this.restService.loaderState.subscribe(
      (state: LoaderState) => {
        this.loaderService.showLoader(state.show);
      }
    );
    this.editor = document.getElementById("editor");
    this.setEventDropCommand();
    this.route.paramMap.subscribe(params => {
      const currentId = params.get('reportId');
      if (currentId !== null) {
        this.titleService.setTitle("Sửa mẫu kết quả");
        this.titleScreen = "Sửa mẫu kết quả";
        this.isEdit = true;
        this.restService.getReport(currentId)
          .subscribe(
            (data: any) => {
              if (data.groupFlag) {
                this.errorService.setErrorCode(404);
                this.router.navigateByUrl('/error', { replaceUrl: true });
              }
              this.currentId = data.id;
              this.editorComponent.setContentEditor(data.content);
              this.newReportName = data.reportName;
              this.parentGroup = data.parentGroup.id;
              this.setEventMenuContextOnEdit();
            },
            () => {
              this.dialog.open(NotifyDialogComponent, {
                width: '350px',
                disableClose: true,
                autoFocus: false,
                data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
              });
            }
          )
      } else {
        this.titleService.setTitle("Thêm mới mẫu kết quả");
        this.titleScreen = "Thêm mới mẫu kết quả";
        this.isEdit = false;
      }
    });
  }

  loadGroup() {
    this.restService.getAllReport()
      .subscribe(
        (data: any) => {
          for (const report of data) {
            if (!report.groupFlag) {
              continue;
            }
            this.groups.push(report);
          }
          // sort by orderNumber
          this.groups.sort((a: any, b: any) =>
            (a.orderNumber > b.orderNumber) ? 1 : ((b.orderNumber > a.orderNumber) ? -1 : 0)
          );
        },
        () => {
          this.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Lỗi không tải được dữ liệu, vui lòng tải lại trang" },
          });
        }
      )
  }

  setEventMenuContextOnEdit() {
    const inputName = document.getElementById("input-name");
    const inputAge = document.getElementById("input-age");
    const inputAddress = document.getElementById("input-address");
    const inputResult = document.getElementById("input-result");
    const autoDateArr: any = document.getElementsByClassName("auto-date");
    if (inputName !== null) {
      inputName.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        this.contextMenu.openMenuContext(inputName, menuPosition);
      }
    }
    if (inputAge !== null) {
      inputName.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        this.contextMenu.openMenuContext(inputAge, menuPosition);
      }
    }
    if (inputAddress !== null) {
      inputName.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        this.contextMenu.openMenuContext(inputAddress, menuPosition);
      }
    }
    if (inputResult !== null) {
      inputName.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        this.contextMenu.openMenuContext(inputResult, menuPosition);
      }
    }
    for (const autoDate of autoDateArr) {
      const ad: any = autoDate;
      ad.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        this.contextMenu.openMenuContext(ad, menuPosition);
      }
    }
  }

  setEventDropCommand() {
    const thisComponent = this;
    $(this.editor).bind('drop', function (event: any) {
      event.preventDefault();
      thisComponent.editorComponent.saveUndoRedo();

      const originalEvent = event.originalEvent;
      const command = Number(originalEvent.dataTransfer.getData("command"));
      const target = originalEvent.target;
      let appendNode: any;
      if (command === 1) {
        // if insert name input
        const checkNode = document.getElementById("input-name");
        if (checkNode !== null) {
          thisComponent.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Không thể thêm mới, khung nhập tên đã tồn tại" },
          });
          return;
        }
        appendNode = document.createElement("div");
        const contentNode = document.createElement("input");
        contentNode.style.border = 'none';
        contentNode.style.width = '100%';
        contentNode.style.fontSize = '18px';
        contentNode.style.fontFamily = '"Times New Roman",Times,serif';
        contentNode.style.fontWeight = 'bold';
        contentNode.setAttribute("placeholder", "Nhập tên");
        contentNode.setAttribute("id", "input-name");
        appendNode.appendChild(contentNode);
      } else if (command === 2) {
        // if insert age input
        const checkNode = document.getElementById("input-age");
        if (checkNode !== null) {
          thisComponent.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Không thể thêm mới, khung nhập tuổi đã tồn tại" },
          });
          return;
        }
        appendNode = document.createElement("div");
        const contentNode = document.createElement("input");
        contentNode.style.border = 'none';
        contentNode.style.width = '100%';
        contentNode.style.fontSize = '18px';
        contentNode.style.fontFamily = '"Times New Roman",Times,serif';
        contentNode.style.fontWeight = 'bold';
        contentNode.setAttribute("placeholder", "Nhập tuổi");
        contentNode.setAttribute("id", "input-age");
        appendNode.appendChild(contentNode);
      } else if (command === 3) {
        // if insert address input
        const checkNode = document.getElementById("input-address");
        if (checkNode !== null) {
          thisComponent.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Không thể thêm mới, khung nhập địa chỉ đã tồn tại" },
          });
          return;
        }
        appendNode = document.createElement("div");
        const contentNode = document.createElement("input");
        contentNode.style.border = 'none';
        contentNode.style.width = '100%';
        contentNode.style.fontSize = '18px';
        contentNode.style.fontFamily = '"Times New Roman",Times,serif';
        contentNode.style.fontWeight = 'bold';
        contentNode.setAttribute("placeholder", "Nhập địa chỉ");
        contentNode.setAttribute("id", "input-address");
        appendNode.appendChild(contentNode);
      } else if (command === 4) {
        // if insert result input
        const checkNode = document.getElementById("input-result");
        if (checkNode !== null) {
          thisComponent.dialog.open(NotifyDialogComponent, {
            width: '350px',
            disableClose: true,
            autoFocus: false,
            data: { title: "Lỗi", content: "Không thể thêm mới, khung nhập kết quả đã tồn tại" },
          });
          return;
        }
        appendNode = document.createElement("div");
        const contentNode = document.createElement("textarea");
        contentNode.style.border = 'none';
        contentNode.style.resize = 'none';
        contentNode.style.width = '100%';
        contentNode.style.fontWeight = 'bold';
        contentNode.style.whiteSpace = 'pre-line';
        contentNode.style.padding = '0';
        contentNode.style.lineHeight = 'normal';
        contentNode.style.marginTop = '7px';
        contentNode.style.fontSize = '18px';
        contentNode.style.fontFamily = '"Times New Roman",Times,serif';
        contentNode.setAttribute("placeholder", "Nhập kết quả");
        contentNode.setAttribute("rows", "1");
        contentNode.setAttribute("id", "input-result");
        appendNode.appendChild(contentNode);
      } else if (command === 5) {
        // if insert auto date
        appendNode = document.createElement("i");
        appendNode.style.fontSize = "1 rem";
        const bTag = document.createElement("b");
        bTag.setAttribute("class", "auto-date");
        appendNode.appendChild(bTag);
      }
      appendNode.oncontextmenu = (event: any) => {
        event.preventDefault();
        const menuPosition = {
          positionX: event.clientX,
          positionY: event.clientY
        }
        thisComponent.contextMenu.openMenuContext(appendNode, menuPosition);
      }
      target.appendChild(appendNode);
      thisComponent.editorComponent.setAutoDate();
      thisComponent.editorComponent.initTextArea();
      return false;
    });
  }

  onDragStart(event: any, command: number) {
    event.dataTransfer.setData("command", command);
  }

  print() {
    const listTable: any = this.editor.getElementsByTagName('table');
    for (const table of listTable) {
      $(table).colResizable({
        disable: true
      });
    }
    $("#editor").printThis({ importCSS: false });
    setTimeout(function () {
      for (const table of listTable) {
        $(table).colResizable({
          liveDrag: true,
          draggingClass: "dragging"
        });
      }
    }, 1500);
  }

  save() {
    if (this.newReportName === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Tên mẫu kết quả không được bỏ trống" },
      });
      return;
    }
    this.newReportName = this.newReportName.trim();
    if (this.newReportName.length === 0) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Tên mẫu kết quả không được chứa toàn bộ dấu cách" },
      });
      return;
    }
    if ($('#input-name').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập tên" },
      });
      return;
    }

    if ($('#input-age').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập tuổi" },
      });
      return;
    }

    if ($('#input-address').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập địa chỉ" },
      });
      return;
    }

    if ($('#input-result').val() === undefined) {
      this.dialog.open(NotifyDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: { title: "Lỗi", content: "Không thể thực hiện thao tác lưu, không tìm thấy chỗ nhập kết quả" },
      });
      return;
    }

    const listTable: any = this.editor.getElementsByTagName('table');
    for (const table of listTable) {
      $(table).colResizable({
        disable: true
      });
    }
    $('#input-result').html($('#input-result').val());

    const reportContent = this.editor.innerHTML;

    if (!this.isEdit) {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: {
          title: "Thông báo",
          content: "Bạn có muốn tạo mới mẫu kết quả này không?"
        },
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.restService.addReport(this.newReportName, reportContent, "false", this.parentGroup, null)
            .subscribe(
              () => {
                const dialogRefNoti = this.dialog.open(NotifyDialogComponent, {
                  width: '350px',
                  disableClose: true,
                  autoFocus: false,
                  data: { title: "Thông báo", content: "Thêm mới mẫu kết quả thành công" },
                });

                dialogRefNoti.afterClosed().subscribe(() => {
                  this.sidebarService.reloadDataSidebar();
                });
              },
              () => {
                this.dialog.open(NotifyDialogComponent, {
                  width: '350px',
                  disableClose: true,
                  autoFocus: false,
                  data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
                });
              }
            )
        }
      });
    } else {
      const dialogRef = this.dialog.open(ConfirmDialogComponent, {
        width: '350px',
        disableClose: true,
        autoFocus: false,
        data: {
          title: "Thông báo",
          content: "Bạn có muốn sửa mẫu kết quả này không?"
        },
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.restService.updateReport(this.currentId, this.newReportName, reportContent, "false", this.parentGroup, null)
            .subscribe(
              () => {
                this.dialog.open(NotifyDialogComponent, {
                  width: '350px',
                  disableClose: true,
                  autoFocus: false,
                  data: { title: "Thông báo", content: "Sửa mẫu kết quả thành công" },
                });
                this.sidebarService.reloadDataSidebar();
              },
              () => {
                this.dialog.open(NotifyDialogComponent, {
                  width: '350px',
                  disableClose: true,
                  autoFocus: false,
                  data: { title: "Lỗi", content: "Lỗi máy chủ gặp sự cố, vui lòng thử lại" },
                });
              }
            )
        }
      });
    }
  }

}
