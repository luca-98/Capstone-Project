package com.github.duc010298.cms.repository;

import com.github.duc010298.cms.entity.ActivityEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivityRepository extends JpaRepository<ActivityEntity, Integer> {

}