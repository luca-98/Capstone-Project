package com.github.duc010298.cms.dto;

import com.github.duc010298.cms.entity.AppRoleEntity;

import java.util.Collection;

public class ActivityInfoDTO {
    private Integer id;
    private String key;
    private String info;
    private Collection<AppRoleEntity> role;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Collection<AppRoleEntity> getRole() {
        return role;
    }

    public void setRole(Collection<AppRoleEntity> role) {
        this.role = role;
    }
}
