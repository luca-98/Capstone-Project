package com.github.duc010298.cms.services;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Component
public class DateTimeService {

    public Calendar getCalendarToday() {
        final Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        calendar.set(Calendar.HOUR_OF_DAY, 0); // ! clear would not reset the hour of day !
        calendar.clear(Calendar.MINUTE);
        calendar.clear(Calendar.SECOND);
        calendar.clear(Calendar.MILLISECOND);
        return calendar;
    }

    public Calendar getCalendarYesterday() {
        final Calendar calendar = getCalendarToday();
        calendar.add(Calendar.DATE, -1);
        return calendar;
    }

    public Calendar getCalendarMondayOfCurrentWeek() {
        final Calendar calendar = getCalendarToday();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return calendar;
    }

    public Calendar getCalendarMondayOfLastWeek() {
        final Calendar calendar = getCalendarToday();
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        calendar.add(Calendar.DATE, -7);
        return calendar;
    }

    public Calendar getCalendarSundayOfLastWeek() {
        final Calendar calendar = getCalendarMondayOfLastWeek();
        calendar.add(Calendar.DATE, 6);
        return calendar;
    }

    public Calendar getCalendarFirstDayOfCurrentMonth() {
        final Calendar calendar = getCalendarToday();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return calendar;
    }

    public Calendar getCalendarFirstDayOfLastMonth() {
        final Calendar calendar = getCalendarFirstDayOfCurrentMonth();
        calendar.add(Calendar.MONTH, -1);
        return calendar;
    }

    public Calendar getCalendarLastDayOfLastMonth() {
        final Calendar calendar = getCalendarFirstDayOfLastMonth();
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return calendar;
    }

    public Calendar getCalendarFirstDayOfCurrentYear() {
        final Calendar calendar = getCalendarToday();
        calendar.set(Calendar.DAY_OF_YEAR, 1);
        return calendar;
    }

    public Calendar getCalendarFirstDayOfLastYear() {
        final Calendar calendar = getCalendarFirstDayOfCurrentYear();
        calendar.add(Calendar.YEAR, -1);
        return calendar;
    }

    public Calendar getCalendarLastDayOfLastYear() {
        final Calendar calendar = getCalendarFirstDayOfLastYear();
        calendar.set(Calendar.MONTH, 11);
        calendar.set(Calendar.DAY_OF_MONTH, 31);
        return calendar;
    }

    public Calendar getFirstDateOfMonth(Date date) {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return calendar;
    }

    public Calendar getLastDateOfMonth(Date date) {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return calendar;
    }

    public String formatDate(String format, Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }
}
