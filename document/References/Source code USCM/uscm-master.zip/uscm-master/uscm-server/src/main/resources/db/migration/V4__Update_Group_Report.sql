alter table report_form
    add group_flag boolean not null;

alter table report_form
    add group_id uuid;

alter table report_form
    add constraint report_form_fk foreign key (group_id) references report_form (id)