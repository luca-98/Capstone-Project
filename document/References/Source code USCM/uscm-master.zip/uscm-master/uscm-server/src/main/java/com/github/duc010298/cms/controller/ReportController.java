package com.github.duc010298.cms.controller;

import com.github.duc010298.cms.entity.ReportFormEntity;
import com.github.duc010298.cms.repository.ReportFormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.*;

@RestController
@RequestMapping("/reports")
public class ReportController {
    private ReportFormRepository reportFormRepository;

    @Autowired
    public ReportController(ReportFormRepository reportFormRepository) {
        this.reportFormRepository = reportFormRepository;
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<ReportFormEntity> getReport(@PathVariable("id") UUID id) {
        Optional<ReportFormEntity> reportOptional = reportFormRepository.findById(id);
        if (!reportOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.OK).body(reportOptional.get());
    }

    @GetMapping
    public List<ReportFormEntity> getAllReport() {
        return reportFormRepository.findAll();
    }

    @DeleteMapping(path = "/delete-reports", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteReports(@RequestBody List<ReportFormEntity> reportFormEntities) {
        for (ReportFormEntity r : reportFormEntities) {
            Optional<ReportFormEntity> reportFormEntityOptional = reportFormRepository.findById(r.getId());
            if (!reportFormEntityOptional.isPresent()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            ReportFormEntity group = reportFormEntityOptional.get();
            if (group.getGroupFlag()) {
                List<ReportFormEntity> formEntityList = reportFormRepository.findAllByParentGroup(group);
                if (formEntityList.size() > 0) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                }
            }
        }
        reportFormRepository.deleteAll(reportFormEntities);
        List<ReportFormEntity> listReportInDatabase = reportFormRepository.findAll();
        Collections.sort(listReportInDatabase, Comparator.comparingInt(ReportFormEntity::getOrderNumber));
        for (int i = 0; i < listReportInDatabase.size(); i++) {
            listReportInDatabase.get(i).setOrderNumber(i);
        }
        reportFormRepository.saveAll(listReportInDatabase);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateReports(@RequestBody List<ReportFormEntity> reportList) {
        // check total
        List<ReportFormEntity> listReportInDatabase = reportFormRepository.findAll();
        if (listReportInDatabase.size() != reportList.size()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        for (ReportFormEntity r : listReportInDatabase) {
            boolean haveItem = false;
            for (ReportFormEntity report : reportList) {
                if (r.getId().equals(report.getId())) {
                    haveItem = true;
                }
            }
            if (!haveItem) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        }

        Collections.sort(reportList, Comparator.comparingInt(ReportFormEntity::getOrderNumber));

        for (int i = 0; i < reportList.size(); i++) {
            if (reportList.get(i).getOrderNumber() != i) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        }
        // validate order
        for (int i = 0; i < reportList.size(); i++) {
            if (reportList.get(i).getGroupFlag()) {
                for (int j = 0; j < reportList.size(); j++) {
                    if (reportList.get(j).getParentGroup() != null
                            && reportList.get(j).getParentGroup().getId().equals(reportList.get(i).getId())
                            && reportList.get(j).getOrderNumber() < reportList.get(i).getOrderNumber()) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                    }
                }
                // count total child
                int count = 0;
                for (int j = i + 1; j < reportList.size(); j++) {
                    if (reportList.get(j).getParentGroup() != null
                            && reportList.get(j).getParentGroup().getId().equals(reportList.get(i).getId())) {
                        count++;
                    }
                }
                // check children position
                for (int j = 1; j <= count; j++) {
                    if (reportList.get(i + j).getOrderNumber() != reportList.get(i).getOrderNumber() + j) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                    }
                    if (reportList.get(i + j).getParentGroup() == null) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                    }
                    if (!reportList.get(i + j).getParentGroup().getId().equals(reportList.get(i).getId())) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                    }
                }
            }
        }
        reportFormRepository.saveAll(reportList);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<?> updateReport(@PathVariable("id") UUID id,
                                          @RequestParam("reportName") String reportName,
                                          @RequestParam(value = "content", required = false) String content,
                                          @RequestParam("groupFlag") Boolean groupFlag,
                                          @RequestParam(value = "parentId", required = false) UUID parentId,
                                          @RequestParam(value = "groupOpenDefault", required = false) Boolean groupOpenDefault) {
        ReportFormEntity parentGroup = null;
        if (groupFlag == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if ((groupFlag && groupOpenDefault == null) || (!groupFlag && groupOpenDefault != null)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (groupFlag && (reportName == null || reportName.isEmpty() || parentId != null || content != null)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (!groupFlag && (reportName == null || content == null || reportName.isEmpty())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (!groupFlag && parentId != null) {
            Optional<ReportFormEntity> parentGroupOptional = reportFormRepository.findById(parentId);
            parentGroup = parentGroupOptional.get();
            if (!parentGroupOptional.isPresent()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        }
        Optional<ReportFormEntity> reportOptional = reportFormRepository.findById(id);
        if (!reportOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        ReportFormEntity report = reportOptional.get();

        if ((report.getParentGroup() == null && parentId != null)
                || (report.getParentGroup() != null && !report.getParentGroup().getId().equals(parentId))) {
            List<ReportFormEntity> listReportInDatabase = reportFormRepository.findAll();
            Collections.sort(listReportInDatabase, Comparator.comparingInt(ReportFormEntity::getOrderNumber));

            Integer order = 0;
            order = reportFormRepository.getMaxOrderNumber();
            if (order == null) {
                order = 0;
            }

            for (int i = 0; i < listReportInDatabase.size(); i++) {
                if (listReportInDatabase.get(i).getId().equals(report.getId())) {
                    for (int j = i + 1; j < listReportInDatabase.size(); j++) {
                        listReportInDatabase.get(j).setOrderNumber(listReportInDatabase.get(j).getOrderNumber() - 1);
                    }
                }
            }
            if (parentId != null) {
                for (int i = 0; i < listReportInDatabase.size(); i++) {
                    if (listReportInDatabase.get(i).getId().equals(parentId)) {
                        for (int j = i + 1; j < listReportInDatabase.size(); j++) {
                            if (listReportInDatabase.get(j).getParentGroup() == null) {
                                order = listReportInDatabase.get(j).getOrderNumber();
                                for (int k = j; k < listReportInDatabase.size(); k++) {
                                    listReportInDatabase.get(k).setOrderNumber(listReportInDatabase.get(k).getOrderNumber() + 1);
                                }
                                break;
                            }
                        }
                    }
                }
            }
            report.setOrderNumber(order);
            reportFormRepository.saveAll(listReportInDatabase);
        }

        report.setReportName(reportName);
        report.setContent(content);
        report.setGroupFlag(groupFlag);
        report.setParentGroup(parentGroup);
        report.setGroupOpenDefault(groupOpenDefault);

        report.setLastEdit(new Timestamp(new Date().getTime()));
        reportFormRepository.save(report);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping
    public ResponseEntity<?> addReport(@RequestParam("reportName") String reportName,
                                       @RequestParam(value = "content", required = false) String content,
                                       @RequestParam("groupFlag") Boolean groupFlag,
                                       @RequestParam(value = "parentId", required = false) UUID parentId,
                                       @RequestParam(value = "groupOpenDefault", required = false) Boolean groupOpenDefault) {
        ReportFormEntity parentGroup = null;
        if (groupFlag == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (!groupFlag && (reportName == null || content == null || reportName.isEmpty())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (groupFlag && (reportName == null || reportName.isEmpty() || parentId != null || content != null)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if ((groupFlag && groupOpenDefault == null) || (!groupFlag && groupOpenDefault != null)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        if (!groupFlag && parentId != null) {
            Optional<ReportFormEntity> parentGroupOptional = reportFormRepository.findById(parentId);
            parentGroup = parentGroupOptional.get();
            if (!parentGroupOptional.isPresent()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        }

        ReportFormEntity reportFormEntity = new ReportFormEntity();
        reportFormEntity.setReportName(reportName);
        reportFormEntity.setContent(content);
        reportFormEntity.setGroupFlag(groupFlag);
        reportFormEntity.setParentGroup(parentGroup);
        reportFormEntity.setGroupOpenDefault(groupOpenDefault);

        Integer orderNumber = 0;
        if (parentId == null) {
            orderNumber = reportFormRepository.getMaxOrderNumber();
            if (orderNumber == null) {
                orderNumber = 0;
            } else {
                orderNumber++;
            }
        } else {
            List<ReportFormEntity> listReportInDatabase = reportFormRepository.findAll();
            Collections.sort(listReportInDatabase, Comparator.comparingInt(ReportFormEntity::getOrderNumber));
            for (int i = 0; i < listReportInDatabase.size(); i++) {
                if (listReportInDatabase.get(i).getId().equals(parentGroup.getId())) {
                    orderNumber = i + 1;
                    for (int j = i + 1; j < listReportInDatabase.size(); j++) {
                        if (listReportInDatabase.get(j).getParentGroup().getId().equals(parentGroup.getId())) {
                            orderNumber = j + 1;
                        }
                        if (listReportInDatabase.get(j).getParentGroup() == null) {
                            for (int k = j; k < listReportInDatabase.size(); k++) {
                                listReportInDatabase.get(k).setOrderNumber(listReportInDatabase.get(k).getOrderNumber() + 1);
                                reportFormRepository.save(listReportInDatabase.get(k));
                            }
                            orderNumber = j;
                            break;
                        }
                    }
                }
            }
        }
        Timestamp lastEdit = new Timestamp(new Date().getTime());
        reportFormEntity.setOrderNumber(orderNumber);
        reportFormEntity.setLastEdit(lastEdit);

        reportFormRepository.save(reportFormEntity);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
