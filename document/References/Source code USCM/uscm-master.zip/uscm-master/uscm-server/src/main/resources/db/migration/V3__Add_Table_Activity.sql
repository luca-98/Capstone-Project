create table if not exists activity
(
    id          serial       not null primary key,
    key         varchar(36)  not null unique,
    information varchar(128) not null
);

create table if not exists activity_role
(
    activity_id int not null,
    role_id int not null,
    primary key (activity_id, role_id),
    constraint activity_role_fk1 foreign key (activity_id) references activity (id),
    constraint activity_role_fk2 foreign key (role_id) references app_role (id)
);

insert into activity (id, key, information)
values (1, 'CAN_DELETE_CUSTOMER', 'Can delete customer after saved');

insert into activity (id, key, information)
values (2, 'CAN_EDIT_CUSTOMER', 'Can edit customer after saved');

insert into activity_role (activity_id, role_id)
values (1, 1);

insert into activity_role (activity_id, role_id)
values (2, 1);