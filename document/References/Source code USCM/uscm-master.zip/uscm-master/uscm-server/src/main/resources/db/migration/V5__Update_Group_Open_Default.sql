alter table report_form
    add group_open_default boolean;