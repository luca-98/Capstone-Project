package com.github.duc010298.cms.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "app_role")
public class AppRoleEntity {
    private int id;
    private String roleName;
    private Collection<AppUserEntity> appUserEntities;
    private Collection<ActivityEntity> activityEntities;

    @Id
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "role_name")
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AppRoleEntity that = (AppRoleEntity) o;
        return id == that.id &&
                Objects.equals(roleName, that.roleName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, roleName);
    }

    @JsonIgnore
    @ManyToMany(mappedBy = "appRoleEntities")
    public Collection<AppUserEntity> getAppUserEntities() {
        return appUserEntities;
    }

    public void setAppUserEntities(Collection<AppUserEntity> appRoleEntities) {
        this.appUserEntities = appRoleEntities;
    }

    @JsonIgnore
    @ManyToMany(mappedBy = "appRoleEntities")
    public Collection<ActivityEntity> getActivityEntities() {
        return activityEntities;
    }

    public void setActivityEntities(Collection<ActivityEntity> activityEntities) {
        this.activityEntities = activityEntities;
    }
}
