package com.github.duc010298.cms.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.duc010298.cms.dto.ChartPointDTO;
import com.github.duc010298.cms.dto.CustomerDTO;
import com.github.duc010298.cms.dto.CustomerSearchDTO;
import com.github.duc010298.cms.dto.SummaryDTO;
import com.github.duc010298.cms.entity.ActivityEntity;
import com.github.duc010298.cms.entity.AppRoleEntity;
import com.github.duc010298.cms.entity.CustomerEntity;
import com.github.duc010298.cms.repository.ActivityRepository;
import com.github.duc010298.cms.repository.CustomerRepository;
import com.github.duc010298.cms.services.DateTimeService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    private static final Pageable TOP = PageRequest.of(0, 10);
    private static final Integer CAN_DELETE_CUSTOMER_ID = 1;
    private static final Integer CAN_EDIT_CUSTOMER_ID = 2;

    private CustomerRepository customerRepository;
    private ActivityRepository activityRepository;
    private DateTimeService dateTimeService;

    public CustomerController(CustomerRepository customerRepository, ActivityRepository activityRepository, DateTimeService dateTimeService) {
        this.customerRepository = customerRepository;
        this.activityRepository = activityRepository;
        this.dateTimeService = dateTimeService;
    }

    @PostMapping
    public ResponseEntity<?> addCustomer(@RequestParam("name") String name, @RequestParam("nameSearch") String nameSearch,
                                         @RequestParam("address") String address, @RequestParam("addressSearch") String addressSearch,
                                         @RequestParam("yearOfBirth") String yearOfBirth, @RequestParam("result") String result,
                                         @RequestParam("report") String report,
                                         @RequestParam(value = "phonenumber", required = false) String phoneNumber,
                                         @RequestParam(value = "expectedDateOfBirth", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date expectedDateOfBirth,
                                         @RequestParam(value = "note", required = false) String note) {
        if (name.isEmpty() || nameSearch.isEmpty() || address.isEmpty() || addressSearch.isEmpty()
                || yearOfBirth.isEmpty() || result.isEmpty() || report.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        CustomerEntity customerEntity = new CustomerEntity();
        customerEntity.setName(name);
        customerEntity.setNameSearch(nameSearch);
        customerEntity.setAddress(address);
        customerEntity.setAddressSearch(addressSearch);
        customerEntity.setYearOfBirth(yearOfBirth);
        customerEntity.setResult(result);
        customerEntity.setReport(report);
        Timestamp dayVisit = new Timestamp(new Date().getTime());
        customerEntity.setDayVisit(dayVisit);
        customerEntity.setPhoneNumber(phoneNumber);
        customerEntity.setExpectedDateOfBirth(expectedDateOfBirth);
        customerEntity.setNote(note);
        customerRepository.save(customerEntity);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<?> editCustomer(@PathVariable("id") UUID id,
                                          @RequestParam("name") String name, @RequestParam("nameSearch") String nameSearch,
                                          @RequestParam("address") String address, @RequestParam("addressSearch") String addressSearch,
                                          @RequestParam("yearOfBirth") String yearOfBirth, @RequestParam("result") String result,
                                          @RequestParam("report") String report,
                                          @RequestParam(value = "phonenumber", required = false) String phonenumber,
                                          @RequestParam(value = "expectedDateOfBirth", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date expectedDateOfBirth,
                                          @RequestParam(value = "note", required = false) String note,
                                          @RequestParam(value = "dayVisit", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date dayVisit, Authentication authentication) {
        if (!checkAccess(authentication, CAN_EDIT_CUSTOMER_ID)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        if (name.isEmpty() || nameSearch.isEmpty() || address.isEmpty() || addressSearch.isEmpty()
                || yearOfBirth.isEmpty() || result.isEmpty() || report.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        CustomerEntity customerEntity = new CustomerEntity();
        customerEntity.setId(id);
        customerEntity.setDayVisit(dayVisit);
        customerEntity.setName(name);
        customerEntity.setNameSearch(nameSearch);
        customerEntity.setAddress(address);
        customerEntity.setAddressSearch(addressSearch);
        customerEntity.setYearOfBirth(yearOfBirth);
        customerEntity.setResult(result);
        customerEntity.setReport(report);
        customerEntity.setPhoneNumber(phonenumber);
        customerEntity.setExpectedDateOfBirth(expectedDateOfBirth);
        customerEntity.setNote(note);
        customerRepository.save(customerEntity);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable("id") UUID id, Authentication authentication) {
        if (!checkAccess(authentication, CAN_DELETE_CUSTOMER_ID)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Optional<CustomerEntity> customerOptional = customerRepository.findById(id);
        if (customerOptional.isPresent()) {
            customerRepository.delete(customerOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    private boolean checkAccess(Authentication authentication, Integer roleId) {
        Collection<? extends GrantedAuthority> grantedAuthorityCollection = authentication.getAuthorities();
        ActivityEntity activityEntity = activityRepository.findById(roleId).get();
        Collection<AppRoleEntity> roleAcceptList = activityEntity.getAppRoleEntities();
        for (AppRoleEntity role : roleAcceptList) {
            for (GrantedAuthority grantedAuthority : grantedAuthorityCollection) {
                if (grantedAuthority.getAuthority().equals(role.getRoleName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @GetMapping("search-name-auto")
    public List<String> getAutoName(@RequestParam("value") String value) {
        value = '%' + value + '%';
        return customerRepository.searchByName(value, TOP);
    }

    @GetMapping("search-year-of-birth-auto")
    public List<String> getAutoYearOfBirth(@RequestParam("value") String value) {
        value = '%' + value + '%';
        return customerRepository.searchByYearOfBirth(value, TOP);
    }

    @GetMapping("search-address-auto")
    public List<String> getAutoAddress(@RequestParam("value") String value) {
        value = '%' + value + '%';
        return customerRepository.searchByAddress(value, TOP);
    }

    @GetMapping("search-customer")
    public ResponseEntity<?> searchCustomer(@RequestParam("nameSearch") String nameSearch, @RequestParam("yearOfBirth") String yearOfBirth,
                                            @RequestParam("addressSearch") String addressSearch,
                                            @RequestParam(value = "dayVisit", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date dayVisit,
                                            @RequestParam(value = "dateRangeStart", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date dateRangeStart,
                                            @RequestParam(value = "dateRangeEnd", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date dateRangeEnd,
                                            @RequestParam(value = "pageSize") Integer pageSize, @RequestParam(value = "pageIndex") Integer pageIndex) {
        nameSearch = '%' + nameSearch + '%';
        yearOfBirth = '%' + yearOfBirth + '%';
        addressSearch = '%' + addressSearch + '%';
        Pageable pageable;
        if (pageSize == null || pageIndex == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        pageable = PageRequest.of(pageIndex, pageSize);

        CustomerSearchDTO customerSearchDTO = new CustomerSearchDTO();
        if (dayVisit == null && dateRangeStart == null && dateRangeEnd == null) {
            customerSearchDTO.setPageIndex(pageIndex);
            customerSearchDTO.setPageSize(pageSize);
            customerSearchDTO.setTotalRecord(customerRepository.countSearchWithoutDate(nameSearch, yearOfBirth, addressSearch));
            customerSearchDTO.setCustomerEntityList(customerRepository.searchWithoutDate(nameSearch, yearOfBirth, addressSearch, pageable));
            return ResponseEntity.status(HttpStatus.OK).body(customerSearchDTO);
        } else if (dayVisit != null) {
            customerSearchDTO.setPageIndex(pageIndex);
            customerSearchDTO.setPageSize(pageSize);
            customerSearchDTO.setTotalRecord(customerRepository.countSearchWithDate(nameSearch, yearOfBirth, addressSearch, dayVisit));
            customerSearchDTO.setCustomerEntityList(customerRepository.searchWithDate(nameSearch, yearOfBirth, addressSearch, dayVisit, pageable));
            return ResponseEntity.status(HttpStatus.OK).body(customerSearchDTO);
        } else if (dateRangeStart != null && dateRangeEnd != null) {
            customerSearchDTO.setPageIndex(pageIndex);
            customerSearchDTO.setPageSize(pageSize);
            customerSearchDTO.setTotalRecord(customerRepository.countSearchWithDateRange(nameSearch, yearOfBirth, addressSearch, dateRangeStart, dateRangeEnd));
            customerSearchDTO.setCustomerEntityList(customerRepository.searchWithDateRange(nameSearch, yearOfBirth, addressSearch, dateRangeStart, dateRangeEnd, pageable));
            return ResponseEntity.status(HttpStatus.OK).body(customerSearchDTO);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping(value = "/customer-report/{id}")
    public ResponseEntity<?> getCustomerReport(@PathVariable("id") UUID customerId) throws JsonProcessingException {
        Optional<CustomerEntity> customerEntityOptional = customerRepository.findById(customerId);
        if (!customerEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String ret = objectMapper.writeValueAsString(customerEntityOptional.get().getReport());
        return ResponseEntity.status(HttpStatus.OK).body(ret);
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<?> getCustomer(@PathVariable("id") UUID customerId) throws JsonProcessingException {
        Optional<CustomerEntity> customerEntityOptional = customerRepository.findById(customerId);
        if (!customerEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        CustomerEntity customerEntity = customerEntityOptional.get();
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setId(customerEntity.getId());
        customerDTO.setName(customerEntity.getName());
        customerDTO.setAddress(customerEntity.getAddress());
        customerDTO.setYearOfBirth(customerEntity.getYearOfBirth());
        customerDTO.setDayVisit(customerEntity.getDayVisit());
        customerDTO.setExpectedDateOfBirth(customerEntity.getExpectedDateOfBirth());
        customerDTO.setReport(customerEntity.getReport());
        customerDTO.setResult(customerEntity.getResult());
        customerDTO.setNote(customerEntity.getNote());
        customerDTO.setPhoneNumber(customerEntity.getPhoneNumber());
        return ResponseEntity.status(HttpStatus.OK).body(customerDTO);
    }

    @GetMapping("/summary")
    public ResponseEntity<?> getSummary() {
        SummaryDTO summaryDTO = new SummaryDTO();

        Integer totalCustomerInSystem = customerRepository.getTotalCustomerInSystem();
        summaryDTO.setTotalInSystem(totalCustomerInSystem);
        Integer totalToday = customerRepository.getTotalCustomerInDate(dateTimeService.getCalendarToday().getTime());
        summaryDTO.setToday(totalToday);
        Integer totalYesterday = customerRepository.getTotalCustomerInDate(dateTimeService.getCalendarYesterday().getTime());
        summaryDTO.setYesterday(totalYesterday);
        Integer totalLastWeek = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarMondayOfLastWeek().getTime(), dateTimeService.getCalendarSundayOfLastWeek().getTime()
        );
        summaryDTO.setLastWeek(totalLastWeek);
        Integer totalThisWeek = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarMondayOfCurrentWeek().getTime(), dateTimeService.getCalendarToday().getTime()
        );
        summaryDTO.setThisWeek(totalThisWeek);
        Integer totalLastMonth = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarFirstDayOfLastMonth().getTime(), dateTimeService.getCalendarLastDayOfLastMonth().getTime()
        );
        summaryDTO.setLastMonth(totalLastMonth);
        Integer totalThisMonth = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarFirstDayOfCurrentMonth().getTime(), dateTimeService.getCalendarToday().getTime()
        );
        summaryDTO.setThisMonth(totalThisMonth);
        Integer totalLastYear = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarFirstDayOfLastYear().getTime(), dateTimeService.getCalendarLastDayOfLastYear().getTime()
        );
        summaryDTO.setLastYear(totalLastYear);
        Integer totalThisYear = customerRepository.getTotalCustomerInDateRange(
                dateTimeService.getCalendarFirstDayOfCurrentYear().getTime(), dateTimeService.getCalendarToday().getTime()
        );
        summaryDTO.setThisYear(totalThisYear);

        // build chart point range year
        ArrayList<ChartPointDTO> chartPointRangeYear = new ArrayList<>();
        Calendar time = dateTimeService.getCalendarToday();
        for (int i = 0; i < 12; i++) {
            ChartPointDTO chartPointDTO = new ChartPointDTO();
            chartPointDTO.setIndex(i);
            chartPointDTO.setTime(dateTimeService.formatDate(
                    "MM/yyyy", dateTimeService.getFirstDateOfMonth(time.getTime()).getTime()
            ));
            Integer value = customerRepository.getTotalCustomerInDateRange(
                    dateTimeService.getFirstDateOfMonth(time.getTime()).getTime(),
                    dateTimeService.getLastDateOfMonth(time.getTime()).getTime()
            );
            chartPointDTO.setValue(value);
            chartPointRangeYear.add(chartPointDTO);
            time.add(Calendar.MONTH, -1);
        }
        summaryDTO.setRangeYear(chartPointRangeYear);

        // build chart point range month
        ArrayList<ChartPointDTO> chartPointRangeMonth = new ArrayList<>();
        time = dateTimeService.getCalendarToday();
        for (int i = 0; i < 31; i++) {
            ChartPointDTO chartPointDTO = new ChartPointDTO();
            chartPointDTO.setIndex(i);
            chartPointDTO.setTime(dateTimeService.formatDate(
                    "dd/MM", time.getTime()
            ));
            Integer value = customerRepository.getTotalCustomerInDate(time.getTime());
            chartPointDTO.setValue(value);
            chartPointRangeMonth.add(chartPointDTO);
            time.add(Calendar.DATE, -1);
        }
        summaryDTO.setRangeMonth(chartPointRangeMonth);

        // build chart point range week
        ArrayList<ChartPointDTO> chartRangeWeek = new ArrayList<>();
        time = dateTimeService.getCalendarToday();
        for (int i = 0; i < 7; i++) {
            ChartPointDTO chartPointDTO = new ChartPointDTO();
            chartPointDTO.setIndex(i);
            chartPointDTO.setTime(String.valueOf(time.get(Calendar.DAY_OF_WEEK)));
            Integer value = customerRepository.getTotalCustomerInDate(time.getTime());
            chartPointDTO.setValue(value);
            chartRangeWeek.add(chartPointDTO);
            time.add(Calendar.DATE, -1);
        }
        summaryDTO.setRangeWeek(chartRangeWeek);

        return ResponseEntity.status(HttpStatus.OK).body(summaryDTO);
    }
}
