package com.github.duc010298.cms.dto;

import java.util.ArrayList;

public class SummaryDTO {
    private int totalInSystem;
    private int yesterday;
    private int today;
    private int lastWeek;
    private int thisWeek;
    private int lastMonth;
    private int thisMonth;
    private int lastYear;
    private int thisYear;
    private ArrayList<ChartPointDTO> rangeYear;
    private ArrayList<ChartPointDTO> rangeMonth;
    private ArrayList<ChartPointDTO> rangeWeek;

    public int getTotalInSystem() {
        return totalInSystem;
    }

    public void setTotalInSystem(int totalInSystem) {
        this.totalInSystem = totalInSystem;
    }

    public int getYesterday() {
        return yesterday;
    }

    public void setYesterday(int yesterday) {
        this.yesterday = yesterday;
    }

    public int getToday() {
        return today;
    }

    public void setToday(int today) {
        this.today = today;
    }

    public int getLastWeek() {
        return lastWeek;
    }

    public void setLastWeek(int lastWeek) {
        this.lastWeek = lastWeek;
    }

    public int getThisWeek() {
        return thisWeek;
    }

    public void setThisWeek(int thisWeek) {
        this.thisWeek = thisWeek;
    }

    public int getLastMonth() {
        return lastMonth;
    }

    public void setLastMonth(int lastMonth) {
        this.lastMonth = lastMonth;
    }

    public int getThisMonth() {
        return thisMonth;
    }

    public void setThisMonth(int thisMonth) {
        this.thisMonth = thisMonth;
    }

    public int getLastYear() {
        return lastYear;
    }

    public void setLastYear(int lastYear) {
        this.lastYear = lastYear;
    }

    public int getThisYear() {
        return thisYear;
    }

    public void setThisYear(int thisYear) {
        this.thisYear = thisYear;
    }

    public ArrayList<ChartPointDTO> getRangeYear() {
        return rangeYear;
    }

    public void setRangeYear(ArrayList<ChartPointDTO> rangeYear) {
        this.rangeYear = rangeYear;
    }

    public ArrayList<ChartPointDTO> getRangeMonth() {
        return rangeMonth;
    }

    public void setRangeMonth(ArrayList<ChartPointDTO> rangeMonth) {
        this.rangeMonth = rangeMonth;
    }

    public ArrayList<ChartPointDTO> getRangeWeek() {
        return rangeWeek;
    }

    public void setRangeWeek(ArrayList<ChartPointDTO> rangeWeek) {
        this.rangeWeek = rangeWeek;
    }
}