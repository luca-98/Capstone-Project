package com.github.duc010298.cms.controller;

import com.github.duc010298.cms.entity.AppRoleEntity;
import com.github.duc010298.cms.entity.AppUserEntity;
import com.github.duc010298.cms.repository.AppRoleRepository;
import com.github.duc010298.cms.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {
    private AppUserRepository appUserRepository;
    private AppRoleRepository appRoleRepository;

    @Autowired
    public UserController(AppUserRepository appUserRepository, AppRoleRepository appRoleRepository) {
        this.appUserRepository = appUserRepository;
        this.appRoleRepository = appRoleRepository;
    }

    @GetMapping
    public List<AppUserEntity> getAllUser() {
        return appUserRepository.findAll();
    }

    @GetMapping(value = "{id}/roles")
    public ResponseEntity<List<AppRoleEntity>> getAllRoleByUserId(@PathVariable("id") Integer userId) {
        Optional<AppUserEntity> appUserEntityOptional = appUserRepository.findById(userId);
        if (!appUserEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        List<AppRoleEntity> appRoleEntities = new ArrayList<>(appUserEntityOptional.get().getAppRoleEntities());
        return ResponseEntity.status(HttpStatus.OK).body(appRoleEntities);
    }

    @DeleteMapping(path = "delete-users", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteUsers(@RequestBody List<AppUserEntity> appUserEntities) {
        // check have any user root
        for (AppUserEntity appUserEntity : appUserEntities) {
            Optional<AppUserEntity> appUserEntityOptional = appUserRepository.findById(appUserEntity.getId());
            if (appUserEntityOptional.isPresent()) {
                AppUserEntity appUser = appUserEntityOptional.get();
                List<AppRoleEntity> listRole = new ArrayList<>(appUser.getAppRoleEntities());
                for (AppRoleEntity role : listRole) {
                    if (role.getRoleName().equals("ROLE_ROOT")) {
                        return ResponseEntity.status(HttpStatus.LOCKED).build();
                    }
                }
            }
        }
        appUserRepository.deleteAll(appUserEntities);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping
    public ResponseEntity<?> addUser(@RequestParam("username") String username, @RequestParam("password") String password,
                                     @RequestParam("fullName") String fullName, @RequestParam("roleName") String roleName) {
        if (invalidData(username) || invalidData(password) || invalidData(fullName) || invalidData(roleName)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        AppRoleEntity role = appRoleRepository.findByRoleName(roleName);
        if (role == null || roleName.equals("ROLE_ROOT")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        AppUserEntity user = appUserRepository.findByUserName(username);
        if (user != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encryptPassword = passwordEncoder.encode(password);

        user = new AppUserEntity();
        user.setUserName(username);
        user.setFullName(fullName);
        user.setEncryptedPassword(encryptPassword);
        List<AppRoleEntity> listRole = new ArrayList<>();
        listRole.add(role);
        user.setAppRoleEntities(listRole);
        appUserRepository.save(user);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<?> editUser(@PathVariable("id") Integer id, @RequestParam("fullName") String fullName,
                                      @RequestParam("password") String password, @RequestParam("roleName") String roleName) {
        if (invalidData(fullName) || invalidData(password)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Optional<AppUserEntity> appUserEntityOptional = appUserRepository.findById(id);
        if (!appUserEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        AppUserEntity appUserEntity = appUserEntityOptional.get();
        List<AppRoleEntity> appRoleEntities = new ArrayList<>(appUserEntity.getAppRoleEntities());
        for (AppRoleEntity role : appRoleEntities) {
            if (role.getRoleName().equals("ROLE_ROOT")) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
        }
        AppRoleEntity role = appRoleRepository.findByRoleName(roleName);
        if (role == null || roleName.equals("ROLE_ROOT")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encryptPassword = passwordEncoder.encode(password);

        List<AppRoleEntity> listRole = new ArrayList<>();
        listRole.add(role);
        appUserEntity.setFullName(fullName);
        appUserEntity.setEncryptedPassword(encryptPassword);
        appUserEntity.setAppRoleEntities(listRole);
        appUserRepository.save(appUserEntity);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    private boolean invalidData(String value) {
        return value == null || value.isEmpty();
    }
}
