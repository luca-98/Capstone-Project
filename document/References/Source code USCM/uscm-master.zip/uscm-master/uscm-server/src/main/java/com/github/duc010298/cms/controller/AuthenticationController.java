package com.github.duc010298.cms.controller;

import java.security.Principal;
import java.util.List;

import com.github.duc010298.cms.dto.UserLoginDTO;
import com.github.duc010298.cms.entity.AppUserEntity;
import com.github.duc010298.cms.repository.AppRoleRepository;
import com.github.duc010298.cms.repository.AppUserRepository;
import com.github.duc010298.cms.services.TokenAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class AuthenticationController {

    private AuthenticationManager authenticationManager;
    private AppUserRepository appUserRepository;
    private AppRoleRepository appRoleRepository;
    private TokenAuthenticationService tokenService;


    @Autowired
    public AuthenticationController(AuthenticationManager authenticationManager, AppUserRepository appUserRepository,
                                    AppRoleRepository appRoleRepository, TokenAuthenticationService tokenService) {
        this.authenticationManager = authenticationManager;
        this.appUserRepository = appUserRepository;
        this.appRoleRepository = appRoleRepository;
        this.tokenService = tokenService;
    }

    @PostMapping("/login")
    public ResponseEntity<UserLoginDTO> login(@RequestParam("username") String userName, @RequestParam("password") String password) {
        try {
            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userName, password);
            Authentication authentication = authenticationManager.authenticate(usernamePasswordAuthenticationToken);
            if (isAuthenticated(authentication)) {
                AppUserEntity appUserEntity = appUserRepository.findByUserName(userName);
                List<String> role = appRoleRepository.getRoleNames(appUserEntity.getId());
                UserLoginDTO userLoginDTO = new UserLoginDTO();
                userLoginDTO.setFullName(appUserEntity.getFullName());
                userLoginDTO.setToken(tokenService.getToken(userName));
                userLoginDTO.setRole(role);

                return ResponseEntity.status(HttpStatus.OK).body(userLoginDTO);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    private boolean isAuthenticated(Authentication authentication) {
        return authentication != null && !(authentication instanceof AnonymousAuthenticationToken)
                && authentication.isAuthenticated();
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestParam("oldPassword") String oldPassword,
                                            @RequestParam("newPassword") String newPassword, Principal principal) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String username = principal.getName();

        AppUserEntity appUserEntity = appUserRepository.findByUserName(username);
        if (!passwordEncoder.matches(oldPassword, appUserEntity.getEncryptedPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        String newEncryptPassword = passwordEncoder.encode(newPassword);
        appUserEntity.setEncryptedPassword(newEncryptPassword);
        appUserRepository.save(appUserEntity);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
