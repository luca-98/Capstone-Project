package com.github.duc010298.cms.controller;

import com.github.duc010298.cms.dto.ActivityInfoDTO;
import com.github.duc010298.cms.entity.ActivityEntity;
import com.github.duc010298.cms.entity.AppRoleEntity;
import com.github.duc010298.cms.repository.ActivityRepository;
import com.github.duc010298.cms.repository.AppRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/activity")
public class ActivityController {
    private ActivityRepository activityRepository;
    private AppRoleRepository appRoleRepository;

    @Autowired
    public ActivityController(ActivityRepository activityRepository, AppRoleRepository appRoleRepository) {
        this.activityRepository = activityRepository;
        this.appRoleRepository = appRoleRepository;
    }

    @GetMapping("/info")
    public ResponseEntity<?> getActivityInfo() {
        List<ActivityInfoDTO> activityInfoDTOList = new ArrayList<>();
        List<ActivityEntity> activityEntityList = activityRepository.findAll();
        for (ActivityEntity activityEntity : activityEntityList) {
            ActivityInfoDTO activityInfoDTO = new ActivityInfoDTO();
            activityInfoDTO.setId(activityEntity.getId());
            activityInfoDTO.setKey(activityEntity.getKey());
            activityInfoDTO.setInfo(activityEntity.getInformation());
            activityInfoDTO.setRole(activityEntity.getAppRoleEntities());
            activityInfoDTOList.add(activityInfoDTO);
        }
        return ResponseEntity.status(HttpStatus.OK).body(activityInfoDTOList);
    }

    @PutMapping
    public ResponseEntity<?> changeActivityCanDelete(@RequestParam("activityId") Integer activityId,
                                                     @RequestParam("roleId") Integer roleId, @RequestParam("status") Boolean status) {
        Optional<AppRoleEntity> appRoleEntityOptional = appRoleRepository.findById(roleId);
        if (!appRoleEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Optional<ActivityEntity> activityEntityOptional = activityRepository.findById(activityId);
        if (!activityEntityOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        ActivityEntity activityEntity = activityEntityOptional.get();

        AppRoleEntity roleRequest = appRoleEntityOptional.get();
        Collection<AppRoleEntity> appRoleEntityList = activityEntity.getAppRoleEntities();

        if (appRoleEntityList.contains(roleRequest)) {
            if (!status) {
                appRoleEntityList.remove(roleRequest);
                activityEntity.setAppRoleEntities(appRoleEntityList);
                activityRepository.save(activityEntity);
            }
        } else {
            if (status) {
                appRoleEntityList.add(roleRequest);
                activityEntity.setAppRoleEntities(appRoleEntityList);
                activityRepository.save(activityEntity);
            }
        }
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
