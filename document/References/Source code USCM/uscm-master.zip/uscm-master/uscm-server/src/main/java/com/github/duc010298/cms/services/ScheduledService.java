package com.github.duc010298.cms.services;

import com.github.duc010298.cms.repository.CustomerRepository;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class ScheduledService {

    private Logger logger = LoggerFactory.getLogger(ScheduledService.class);
    private CustomerRepository customerRepository;

    @Autowired
    public ScheduledService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    //delete customers who visited 1 year ago and have expected birth 3 month ago
    //At 22:00:00pm every day
    @Scheduled(cron = "0 0 22 ? * *")
    public void deleteOldCustomer() {
        logger.info("Scheduled task delete old customer running...");
        Date currentDate = new Date();
        long millisecondsInOneYear = (long) 365 * 24 * 60 * 60 * 1000;
        Date oneYearBefore = new Date(currentDate.getTime() - millisecondsInOneYear);
        customerRepository.deleteCustomerBeforeDay(oneYearBefore);

        long millisecondsInThreeMonth = (long) 30 * 3 * 24 * 60 * 60 * 1000;
        Date threeMonthBefore = new Date(currentDate.getTime() - millisecondsInThreeMonth);
        customerRepository.deleteCustomerExpectedDateBeforeDay(threeMonthBefore);
    }

    //Send public ip to another server
    //At second :00, at minutes :00, :10, :20, :30, :40 and :50, of every hour
    @Scheduled(cron = "0 0,10,20,30,40,50 * ? * *")
    public void sendIpPublic() {
        try {
            final CloseableHttpClient httpClient = HttpClients.createDefault();

            String ip = null;
            HttpGet request = new HttpGet("https://api.myip.com/");
            request.addHeader(HttpHeaders.USER_AGENT, "Googlebot");
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                HttpEntity entity = response.getEntity();

                if (entity != null) {
                    String result = EntityUtils.toString(entity);
                    JSONObject obj = new JSONObject(result);
                    ip = obj.getString("ip");
                    logger.info(ip);
                }
            }

            HttpPost post = new HttpPost("https://phongkham158.herokuapp.com/server-ip");
            List<NameValuePair> urlParameters = new ArrayList<>();
            urlParameters.add(new BasicNameValuePair("ip", ip));
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
            httpClient.execute(post);
        } catch (Exception e) {
            logger.error("Send Ip Public error: {}", e);
        }
    }
}
