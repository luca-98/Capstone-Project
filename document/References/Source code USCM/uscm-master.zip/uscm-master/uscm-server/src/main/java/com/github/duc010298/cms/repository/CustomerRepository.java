package com.github.duc010298.cms.repository;

import com.github.duc010298.cms.entity.CustomerEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface CustomerRepository extends JpaRepository<CustomerEntity, UUID> {

    @Query("select c.name from CustomerEntity c where c.nameSearch like ?1 group by c.name")
    List<String> searchByName(String value, Pageable pageable);

    @Query("select c.yearOfBirth from CustomerEntity c where c.yearOfBirth like ?1 group by c.yearOfBirth")
    List<String> searchByYearOfBirth(String value, Pageable pageable);

    @Query("select c.address from CustomerEntity c where c.addressSearch like ?1 group by c.address")
    List<String> searchByAddress(String value, Pageable pageable);

    @Query("select count(c.id) from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3")
    Integer countSearchWithoutDate(String nameSearch, String yearOfBirth, String addressSearch);

    @Query("from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3 order by c.dayVisit desc")
    List<CustomerEntity> searchWithoutDate(String nameSearch, String yearOfBirth, String addressSearch, Pageable pageable);

    @Query("select count(c.id) from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3 and c.dayVisit=?4")
    Integer countSearchWithDate(String nameSearch, String yearOfBirth, String addressSearch, Date dayVisit);

    @Query("from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3 and c.dayVisit=?4 order by c.dayVisit asc")
    List<CustomerEntity> searchWithDate(String nameSearch, String yearOfBirth, String addressSearch, Date dayVisit, Pageable pageable);

    @Query("select count(c.id) from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3 and c.dayVisit between ?4 and ?5")
    Integer countSearchWithDateRange(String nameSearch, String yearOfBirth, String addressSearch, Date dateRangeStart, Date dateRangeEnd);

    @Query("from CustomerEntity c where c.nameSearch like ?1 and c.yearOfBirth like ?2 and c.addressSearch like ?3 and c.dayVisit between ?4 and ?5 order by c.dayVisit asc")
    List<CustomerEntity> searchWithDateRange(String nameSearch, String yearOfBirth, String addressSearch, Date dateRangeStart, Date dateRangeEnd, Pageable pageable);

    @Query("select count(c.id) from CustomerEntity c")
    Integer getTotalCustomerInSystem();

    @Query("select count(c.id) from CustomerEntity c where c.dayVisit=?1")
    Integer getTotalCustomerInDate(Date dayVisit);

    @Query("select count(c.id) from CustomerEntity c where c.dayVisit between ?1 and ?2")
    Integer getTotalCustomerInDateRange(Date start, Date end);

    @Transactional
    @Modifying
    @Query("delete from CustomerEntity c where c.dayVisit <= ?1")
    void deleteCustomerBeforeDay(Date date);

    @Transactional
    @Modifying
    @Query("delete from CustomerEntity c where c.expectedDateOfBirth <= ?1")
    void deleteCustomerExpectedDateBeforeDay(Date date);
}
