ALTER TABLE customer
ADD phone_number varchar(10);